# Copyright ...
# All rights reserved.

import os
import time
import logging
import pprint
import pickle
import pandas as pd

import numpy as np
import torch
import torch.multiprocessing as mp
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel

import src.models.vision_transformer as vit
from src.models.attentive_pooler import AttentiveClassifier
from src.datasets.data_manager import init_data
from src.utils.distributed import init_distributed, AllReduce
from src.utils.schedulers import WarmupCosineSchedule, CosineWDSchedule
from src.utils.logging import AverageMeter, CSVLogger
from evals.video_classification_frozen.utils import make_transforms, ClipAggregation, FrameAggregation

os.environ['NUMEXPR_MAX_THREADS'] = '16'
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

_GLOBAL_SEED = 0
np.random.seed(_GLOBAL_SEED)
torch.manual_seed(_GLOBAL_SEED)
torch.backends.cudnn.benchmark = False
torch.cuda.manual_seed_all(_GLOBAL_SEED)
os.environ['PYTHONHASHSEED'] = str(_GLOBAL_SEED)

pp = pprint.PrettyPrinter(indent=4)

# =========================
# 纯PyTorch实现的标准LoRA QKV适配器（替换原有自定义适配器）
# =========================
import torch.nn as nn


class LoRAQKVAdapter(nn.Module):
    """
    标准LoRA实现的QKV适配器（不依赖外部库）
    原理：W_qkv = W_qkv_base + A @ B（低秩分解）
    - rank: LoRA秩（r），默认8
    - alpha: 缩放系数，默认16（alpha/r 作为学习率缩放）
    - dropout: Dropout概率，默认0.05
    """

    def __init__(self, qkv_weight_list, rank: int = 8, alpha: int = 16, dropout: float = 0.05,
                 init_scale: float = 1e-2):
        super().__init__()
        assert isinstance(qkv_weight_list, (list, tuple)) and len(qkv_weight_list) > 0
        out_dim, in_dim = qkv_weight_list[0].shape
        assert out_dim == 3 * in_dim, f"Expected [3*D, D], got {qkv_weight_list[0].shape}"

        self.rank = rank
        self.alpha = alpha
        self.dropout = dropout
        self.scaling = alpha / rank  # LoRA缩放系数

        self.B = len(qkv_weight_list)  # QKV层数量
        self.D = in_dim  # 特征维度
        self.out_dim = out_dim  # 3*D

        # 保存原始权重引用和基线
        self.qkv_weight_refs = [w.data for w in qkv_weight_list]
        self.base_weights = [w.detach().clone() for w in qkv_weight_list]

        # 为每个QKV层初始化LoRA参数（A: [out_dim, r], B: [r, in_dim]）
        self.lora_A = nn.ParameterList([
            nn.Parameter(torch.randn(out_dim, rank) * init_scale) for _ in range(self.B)
        ])
        self.lora_B = nn.ParameterList([
            nn.Parameter(torch.zeros(rank, in_dim)) for _ in range(self.B)
        ])

        # Dropout层
        self.lora_dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

        # 初始化B参数（零初始化）
        for b in range(self.B):
            nn.init.zeros_(self.lora_B[b])

    @torch.no_grad()
    def update_weights(self):
        """
        计算LoRA增量并回写到原始QKV权重
        W_new = W_base + (A @ B) * scaling
        """
        for b in range(self.B):
            # 计算低秩增量
            delta = self.lora_A[b] @ self.lora_B[b]
            delta = delta * self.scaling

            # 应用dropout（推理时无影响）
            if self.training and self.dropout > 0:
                delta = self.lora_dropout(delta)

            # 回写到原始权重
            updated_weight = self.base_weights[b] + delta
            self.qkv_weight_refs[b].copy_(updated_weight)

    def forward(self, x):
        """前向传播（仅占位，实际通过update_weights生效）"""
        return x

    def extra_repr(self):
        return f"rank={self.rank}, alpha={self.alpha}, scaling={self.scaling}, dropout={self.dropout}"


def attach_lora_qkv_adapter(encoder: torch.nn.Module, rank: int = 8, alpha: int = 16, dropout: float = 0.05,
                            init_scale: float = 1e-2, logger=None):
    """
    从encoder中找出所有QKV层，挂载纯PyTorch实现的LoRA适配器
    """
    name2module = {name: m for name, m in encoder.named_modules()}
    candidates = []

    # 查找所有QKV层
    for name, module in name2module.items():
        if ("attn.qkv" in name) and hasattr(module, "weight"):
            w = module.weight
            if isinstance(w, torch.Tensor) and w.dim() == 2 and w.shape[0] == 3 * w.shape[1]:
                candidates.append((name, module, w))

    if len(candidates) == 0:
        raise RuntimeError("No fused QKV modules found (expect names containing 'attn.qkv' with weight [3*D, D]).")

    # 按block排序
    def _block_idx(n: str) -> int:
        try:
            parts = n.split(".")
            if "blocks" in parts:
                idx = parts.index("blocks")
                return int(parts[idx + 1])
        except Exception:
            return 10 ** 9
        return 10 ** 9

    candidates = sorted(candidates, key=lambda x: _block_idx(x[0]))
    qkv_weights = [mod.weight for _, mod, _ in candidates]

    # 创建LoRA适配器
    lora_adapter = LoRAQKVAdapter(
        qkv_weights,
        rank=rank,
        alpha=alpha,
        dropout=dropout,
        init_scale=init_scale
    )

    # 日志输出
    if logger:
        logger.info(f"Attached standard LoRA QKV Adapter over {len(qkv_weights)} blocks")
        logger.info(f"LoRA config: rank={rank}, alpha={alpha}, scaling={alpha / rank}, dropout={dropout}")
        logger.info("Example QKV names: " + ", ".join([c[0] for c in candidates[:min(3, len(candidates))]]))

    return lora_adapter, len(qkv_weights)


# =========================
# 原有工具（保持不变）
# =========================
def count_trainable_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def convert_labels_to_multi(original_labels):
    """
    Convert original 3-class labels (0,1,2) to multi-label binary (3 tasks)
    - Label 0 (非2): 1 if original label in [0,1], 0 otherwise
    - Label 1 (非0): 1 if original label in [1,2], 0 otherwise
    - Label 2 (非1): 1 if original label in [0,2], 0 otherwise
    Returns: [batch_size, 3] tensor
    """
    batch_size = original_labels.size(0)
    multi_labels = torch.zeros(batch_size, 3, device=original_labels.device)
    multi_labels[:, 0] = ((original_labels == 0) | (original_labels == 1)).float()
    multi_labels[:, 1] = ((original_labels == 1) | (original_labels == 2)).float()
    multi_labels[:, 2] = ((original_labels == 0) | (original_labels == 2)).float()
    return multi_labels


def extract_video_name(path):
    if isinstance(path, str):
        return os.path.basename(path).split('.')[0]
    return str(path)


def main(args_eval, resume_preempt=False):
    # -------- Extract parameters --------
    args_pretrain = args_eval.get('pretrain', {})
    checkpoint_key = args_pretrain.get('checkpoint_key', 'target_encoder')
    model_name = args_pretrain.get('model_name')
    patch_size = args_pretrain.get('patch_size')
    pretrain_folder = args_pretrain.get('folder')
    ckp_fname = args_pretrain.get('checkpoint')
    tag = args_pretrain.get('write_tag')
    use_sdpa = args_pretrain.get('use_sdpa', True)
    use_SiLU = args_pretrain.get('use_silu', False)
    tight_SiLU = args_pretrain.get('tight_silu', True)
    uniform_power = args_pretrain.get('uniform_power', False)
    pretrained_path = os.path.join(pretrain_folder, ckp_fname)
    tubelet_size = args_pretrain.get('tubelet_size', 2)
    pretrain_frames_per_clip = args_pretrain.get('frames_per_clip', 1)

    args_data = args_eval.get('data', {})
    train_data_path = [args_data.get('dataset_train')]
    val_data_path = [args_data.get('dataset_val')]
    dataset_type = args_data.get('dataset_type', 'VideoDataset')
    num_classes = args_data.get('num_classes')
    eval_num_segments = args_data.get('num_segments', 16)
    eval_frames_per_clip = args_data.get('frames_per_clip', 16)
    eval_frame_step = args_pretrain.get('frame_step', 1)
    eval_duration = args_pretrain.get('clip_duration')
    eval_num_views_per_segment = args_data.get('num_views_per_segment', 1)

    args_opt = args_eval.get('optimization', {})
    resolution = args_opt.get('resolution', 224)
    batch_size = args_opt.get('batch_size')
    attend_across_segments = args_opt.get('attend_across_segments', False)
    num_epochs = args_opt.get('num_epochs')
    wd = args_opt.get('weight_decay')
    start_lr = args_opt.get('start_lr')
    lr = args_opt.get('lr')
    final_lr = args_opt.get('final_lr')
    warmup = args_opt.get('warmup')
    use_bfloat16 = args_opt.get('use_bfloat16', False)

    resume_checkpoint = args_eval.get('resume_checkpoint', False) or resume_preempt
    # 创建权重保存目录
    weights_dir = os.path.join(pretrain_folder, 'weights')
    os.makedirs(weights_dir, exist_ok=True)
    logger.info(f"权重将保存到目录: {weights_dir}")

    try:
        mp.set_start_method('spawn')
    except RuntimeError:
        pass

    device = torch.device('cuda:0') if torch.cuda.is_available() else torch.device('cpu')
    if device.type == 'cuda':
        torch.cuda.set_device(device)

    world_size, rank = init_distributed()
    logger.info(f'Initialized (rank/world-size) {rank}/{world_size}')

    # 创建用于日志/检查点的文件夹
    os.makedirs(pretrain_folder, exist_ok=True)

    log_file = os.path.join(pretrain_folder, f'{tag}_r{rank}.csv')
    latest_path = os.path.join(pretrain_folder, f'{tag}-latest.pth.tar')

    if rank == 0:
        csv_logger = CSVLogger(log_file,
                               ('%d', 'epoch'),
                               ('%.5f', 'loss'),
                               ('%.5f', 'acc_non2'),
                               ('%.5f', 'acc_non0'),
                               ('%.5f', 'acc_non1'),
                               ('%.5f', 'acc_non2_val'),
                               ('%.5f', 'acc_non0_val'),
                               ('%.5f', 'acc_non1_val'))

    # ============= 初始化并冻结编码器 =============
    encoder = init_model(
        crop_size=resolution,
        device=device,
        pretrained=pretrained_path,
        model_name=model_name,
        patch_size=patch_size,
        tubelet_size=tubelet_size,
        frames_per_clip=pretrain_frames_per_clip,
        uniform_power=uniform_power,
        checkpoint_key=checkpoint_key,
        use_SiLU=use_SiLU,
        tight_SiLU=tight_SiLU
    )
    if pretrain_frames_per_clip == 1:
        encoder = FrameAggregation(encoder).to(device)
    else:
        encoder = ClipAggregation(
            encoder,
            tubelet_size=tubelet_size,
            attend_across_segments=attend_across_segments
        ).to(device)

    # 冻结encoder全部参数（仅训练LoRA和分类器）
    for p in encoder.parameters():
        p.requires_grad = False

    # ============= 挂接标准LoRA QKV适配器（替换原有自定义适配器） =============
    lora_rank = 8  # 指定LoRA秩为8
    lora_alpha = 16
    lora_dropout = 0.05
    qkv_adapter, num_blocks = attach_lora_qkv_adapter(
        encoder=encoder,
        rank=lora_rank,
        alpha=lora_alpha,
        dropout=lora_dropout,
        init_scale=1e-2,
        logger=logger
    )
    qkv_adapter = qkv_adapter.to(device)

    # 初始化多标签分类器
    classifier = AttentiveClassifier(
        embed_dim=encoder.embed_dim,
        num_heads=encoder.num_heads,
        depth=1,
        num_classes=3,
    ).to(device)

    # 记录可训练参数的总数
    enc_params = count_trainable_parameters(encoder)
    cls_params = count_trainable_parameters(classifier)
    ada_params = count_trainable_parameters(qkv_adapter)
    logger.info(f"Trainable encoder params: {enc_params:,}")
    logger.info(f"Trainable classifier params: {cls_params:,}")
    logger.info(f"Trainable LoRA adapter params: {ada_params:,}")
    logger.info(f"Total trainable params: {enc_params + cls_params + ada_params:,}")

    # 数据加载器
    train_loader = make_dataloader(
        dataset_type=dataset_type,
        root_path=train_data_path,
        resolution=resolution,
        frames_per_clip=eval_frames_per_clip,
        frame_step=eval_frame_step,
        num_segments=eval_num_segments if attend_across_segments else 1,
        num_views_per_segment=1,
        allow_segment_overlap=True,
        batch_size=batch_size,
        world_size=world_size,
        rank=rank,
        training=True
    )
    val_loader = make_dataloader(
        dataset_type=dataset_type,
        root_path=val_data_path,
        resolution=resolution,
        frames_per_clip=eval_frames_per_clip,
        frame_step=eval_frame_step,
        num_segments=eval_num_segments,
        eval_duration=eval_duration,
        num_views_per_segment=eval_num_views_per_segment,
        allow_segment_overlap=True,
        batch_size=batch_size,
        world_size=world_size,
        rank=rank,
        training=False
    )

    iterations_per_epoch = len(train_loader)
    logger.info(f'Dataloader iterations per epoch: {iterations_per_epoch}')

    # 优化器/调度器（加入LoRA适配器参数组）
    optimizer, scaler, scheduler, wd_scheduler = init_opt(
        classifier=classifier,
        encoder=encoder,
        wd=wd,
        start_lr=start_lr,
        ref_lr=lr,
        warmup=warmup,
        num_epochs=num_epochs,
        final_lr=final_lr,
        iterations_per_epoch=iterations_per_epoch,
        use_bfloat16=use_bfloat16,
        qkv_adapter=qkv_adapter,  # LoRA适配器
        qkv_lr=min(lr, 5e-5),  # LoRA学习率（建议略低）
    )

    start_epoch = 0
    if resume_checkpoint:
        classifier, optimizer, scaler, start_epoch = load_checkpoint(
            device=device,
            r_path=latest_path,
            classifier=classifier,
            opt=optimizer,
            scaler=scaler
        )
        # 回放调度器步数
        for _ in range(start_epoch * iterations_per_epoch):
            scheduler.step()
            wd_scheduler.step()
            for group in optimizer.param_groups:
                if group.get("name") == "encoder":
                    group["lr"] = 1e-6

    # 训练循环
    for epoch in range(start_epoch, num_epochs):
        epoch_start = time.time()
        logger.info(f'Starting epoch {epoch + 1}')

        train_acc_non2, train_acc_non0, train_acc_non1 = run_one_epoch(
            device=device,
            training=True,
            num_temporal_views=eval_num_segments if attend_across_segments else 1,
            attend_across_segments=attend_across_segments,
            num_spatial_views=1,
            encoder=encoder,
            classifier=classifier,
            scaler=scaler,
            optimizer=optimizer,
            scheduler=scheduler,
            wd_scheduler=wd_scheduler,
            data_loader=train_loader,
            use_bfloat16=use_bfloat16,
            save_predictions=False,
            qkv_adapter=qkv_adapter,  # LoRA适配器传入
        )

        # 仅在 epoch 18 到 25 之间保存权重
        if 18 <= epoch + 1 <= 25:
            # 保存LoRA适配器权重
            lora_save_path = os.path.join(weights_dir, f'lora_adapter_epoch_{epoch + 1}.pth')
            torch.save(qkv_adapter.state_dict(), lora_save_path)
            # 保存分类器权重
            classifier_save_path = os.path.join(weights_dir, f'classifier_epoch_{epoch + 1}.pth')
            torch.save(classifier.state_dict(), classifier_save_path)
            # 可选：保存完整encoder（包含LoRA更新后的权重）
            encoder_save_path = os.path.join(weights_dir, f'encoder_epoch_{epoch + 1}.pth')
            torch.save(encoder.state_dict(), encoder_save_path)

            logger.info(f"已保存第 {epoch + 1} 个epoch的LoRA适配器权重到: {lora_save_path}")
            logger.info(f"已保存第 {epoch + 1} 个epoch的classifier权重到: {classifier_save_path}")
            logger.info(f"已保存第 {epoch + 1} 个epoch的encoder权重到: {encoder_save_path}")

        # 验证和日志等其他部分...
        epoch_end = time.time()
        logger.info(f'Epoch {epoch + 1} duration: {epoch_end - epoch_start:.2f} seconds')

        do_validation = (epoch + 1 > 16) and ((epoch) % 1 == 0)
        val_predictions = None

        if do_validation:
            val_acc_non2, val_acc_non0, val_acc_non1, val_predictions = run_one_epoch(
                device=device,
                training=False,
                num_temporal_views=eval_num_segments,
                attend_across_segments=attend_across_segments,
                num_spatial_views=eval_num_views_per_segment,
                encoder=encoder,
                classifier=classifier,
                scaler=scaler,
                optimizer=optimizer,
                scheduler=scheduler,
                wd_scheduler=wd_scheduler,
                data_loader=val_loader,
                use_bfloat16=use_bfloat16,
                save_predictions=True,
                qkv_adapter=qkv_adapter,  # 验证前回写LoRA权重
            )

            if rank == 0 and val_predictions is not None and len(val_predictions) > 0:
                pred_save_path = os.path.join(pretrain_folder, f"{tag}_epoch{epoch + 1}_val_predictions.csv")
                pd.DataFrame(val_predictions).to_csv(pred_save_path, index=False)
                logger.info(f"Saved validation sigmoid predictions for epoch {epoch + 1} to {pred_save_path}")

            logger.info(
                f'[Val][Epoch {epoch + 1}] Acc_non2: {val_acc_non2:.3f}% | Acc_non0: {val_acc_non0:.3f}% | Acc_non1: {val_acc_non1:.3f}%')

        else:
            val_acc_non2, val_acc_non0, val_acc_non1 = 0.0, 0.0, 0.0

        if rank == 0:
            logger.info(
                f'Epoch {epoch + 1:3d} | Train Acc_non2: {train_acc_non2:.3f}% | Train Acc_non0: {train_acc_non0:.3f}% | Train Acc_non1: {train_acc_non1:.3f}% | '
                f'Val Acc_non2: {val_acc_non2:.3f}% | Val Acc_non0: {val_acc_non0:.3f}% | Val Acc_non1: {val_acc_non1:.3f}%'
            )
            csv_logger.log(epoch + 1, 0, train_acc_non2, train_acc_non0, train_acc_non1, val_acc_non2, val_acc_non0,
                           val_acc_non1)

        epoch_end = time.time()
        logger.info(f'Epoch {epoch + 1} duration: {epoch_end - epoch_start:.2f} seconds')


def run_one_epoch(
        device,
        training,
        encoder,
        classifier,
        scaler,
        optimizer,
        scheduler,
        wd_scheduler,
        data_loader,
        use_bfloat16,
        num_spatial_views,
        num_temporal_views,
        attend_across_segments,
        save_predictions=False,
        qkv_adapter=None,  # LoRA适配器
):
    import torch
    from collections import Counter
    import numpy as np
    from torch.nn import functional as F

    if training:
        encoder.train()
        classifier.train()
        if qkv_adapter is not None:
            qkv_adapter.train()
    else:
        encoder.eval()
        classifier.eval()
        if qkv_adapter is not None:
            qkv_adapter.eval()

    criterion = torch.nn.BCEWithLogitsLoss()
    acc_non2_meter = AverageMeter()
    acc_non0_meter = AverageMeter()
    acc_non1_meter = AverageMeter()

    predictions_data = []
    seen_labels = set()
    all_label_list = []

    for itr, data in enumerate(data_loader):
        if training:
            scheduler.step()
            wd_scheduler.step()

        # 在每个前向前应用LoRA权重更新
        if qkv_adapter is not None:
            with torch.no_grad():
                qkv_adapter.update_weights()

        # 修复autocast弃用警告
        with torch.amp.autocast('cuda', dtype=torch.float16, enabled=use_bfloat16):
            clips = [
                [dij.to(device, non_blocking=True) for dij in di]
                for di in data[0]
            ]
            clip_indices = [d.to(device, non_blocking=True) for d in data[2]]
            original_labels = data[1].to(device)
            batch_size = original_labels.size(0)

            # 路径获取
            video_paths = []
            if len(data) > 3:
                for i in range(3, len(data)):
                    if isinstance(data[i], (list, tuple)) and len(data[i]) > 0:
                        if isinstance(data[i][0], str):
                            video_paths = data[i]
                            break
            if not video_paths:
                video_paths = [f"sample_{itr * batch_size + i}" for i in range(batch_size)]

            # 多标签处理
            multi_labels = convert_labels_to_multi(original_labels)

            unique = original_labels.unique().cpu().numpy().tolist()
            seen_labels.update(unique)
            all_label_list.extend(original_labels.cpu().numpy().tolist())

            if not training:
                with torch.no_grad():
                    outputs = encoder(clips, clip_indices)
            else:
                outputs = encoder(clips, clip_indices)

            if attend_across_segments:
                outputs_logits = [classifier(o) for o in outputs]
            else:
                outputs_logits = [[classifier(o) for o in seq] for seq in outputs]

            # 损失
            if attend_across_segments:
                loss = sum(criterion(o, multi_labels) for o in outputs_logits) / len(outputs_logits)
            else:
                loss = sum(sum(criterion(o, multi_labels) for o in seq) for seq in outputs_logits) / (
                        len(outputs_logits) * len(outputs_logits[0])
                )

        with torch.no_grad():
            # 平均 logits
            if attend_across_segments:
                avg_logits = sum(o for o in outputs_logits) / len(outputs_logits)
            else:
                avg_logits = sum(sum(o for o in seq) for seq in outputs_logits) / (
                        len(outputs_logits) * len(outputs_logits[0])
                )

            # 概率（sigmoid）
            pred_probs = torch.sigmoid(avg_logits)  # [B, 3] ∈ (0,1)
            predictions = pred_probs > 0.5
            true_multi = multi_labels.bool()

            # 保存预测
            if save_predictions and not training:
                for i in range(batch_size):
                    video_name = extract_video_name(video_paths[i] if i < len(video_paths) else f"sample_{i}")
                    non0_score = pred_probs[i, 1].cpu().item()
                    predictions_data.append({
                        'video_name': video_name,
                        'video_path': video_paths[i] if i < len(video_paths) else f"sample_{i}",
                        'true_label': original_labels[i].cpu().item(),
                        'pred_non2_score': pred_probs[i, 0].cpu().item(),
                        'pred_non0_score': non0_score,
                        'pred_non1_score': pred_probs[i, 2].cpu().item(),
                        'true_non2': true_multi[i, 0].cpu().item(),
                        'true_non0': true_multi[i, 1].cpu().item(),
                        'true_non1': true_multi[i, 2].cpu().item()
                    })

            # 三任务独立准确率
            acc_non2 = 100. * (predictions[:, 0] == true_multi[:, 0]).float().sum() / batch_size
            acc_non2 = float(AllReduce.apply(acc_non2))
            acc_non2_meter.update(acc_non2)

            acc_non0 = 100. * (predictions[:, 1] == true_multi[:, 1]).float().sum() / batch_size
            acc_non0 = float(AllReduce.apply(acc_non0))
            acc_non0_meter.update(acc_non0)

            acc_non1 = 100. * (predictions[:, 2] == true_multi[:, 2]).float().sum() / batch_size
            acc_non1 = float(AllReduce.apply(acc_non1))
            acc_non1_meter.update(acc_non1)

        # 反传与优化
        if training:
            if use_bfloat16:
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(filter(lambda p: p.requires_grad, encoder.parameters()), 0.2)
                torch.nn.utils.clip_grad_norm_(classifier.parameters(), 1.0)
                # LoRA适配器参数梯度裁剪
                if qkv_adapter is not None:
                    torch.nn.utils.clip_grad_norm_(qkv_adapter.parameters(), 1.0)
                scaler.step(optimizer)
                scaler.update()
            else:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(filter(lambda p: p.requires_grad, encoder.parameters()), 0.2)
                torch.nn.utils.clip_grad_norm_(classifier.parameters(), 1.0)
                if qkv_adapter is not None:
                    torch.nn.utils.clip_grad_norm_(qkv_adapter.parameters(), 1.0)
                optimizer.step()
            optimizer.zero_grad()

        if itr % 20 == 0:
            logger.info(
                f'[{itr:5d}] Acc_non2: {acc_non2_meter.avg:.3f}% | Acc_non0: {acc_non0_meter.avg:.3f}% | Acc_non1: {acc_non1_meter.avg:.3f}% | '
                f'Loss: {loss:.3f} | Mem: {torch.cuda.max_memory_allocated() / 1024. ** 2:.2f} MB'
            )

    logger.info(f"[Epoch End] Seen labels: {sorted(seen_labels)}; Unique count: {len(seen_labels)}")

    if save_predictions and not training:
        return acc_non2_meter.avg, acc_non0_meter.avg, acc_non1_meter.avg, predictions_data
    else:
        return acc_non2_meter.avg, acc_non0_meter.avg, acc_non1_meter.avg


def load_checkpoint(device, r_path, classifier, opt, scaler):
    try:
        ckpt = torch.load(r_path, map_location='cpu')
        epoch = ckpt.get('epoch', 0)
        msg = classifier.load_state_dict(ckpt['classifier'])
        logger.info(f'Loaded classifier from epoch {epoch}: {msg}')
        opt.load_state_dict(ckpt['opt'])
        if scaler:
            scaler.load_state_dict(ckpt['scaler'])
        logger.info(f'Loaded optimizer/scaler from {r_path}')
    except Exception as e:
        logger.info(f'Error loading checkpoint: {e}')
        epoch = 0
    return classifier, opt, scaler, epoch


def load_pretrained(encoder, pretrained, checkpoint_key='target_encoder'):
    logger.info(f'Loading pretrained model from {pretrained}')
    ckpt = torch.load(pretrained, map_location='cpu')
    pdict = ckpt.get(checkpoint_key, ckpt.get('encoder', {}))
    pdict = {k.replace('module.', '').replace('backbone.', ''): v for k, v in pdict.items()}
    model_dict = encoder.state_dict()
    for k in list(model_dict.keys()):
        if k not in pdict or pdict[k].shape != model_dict[k].shape:
            logger.info(f'Key "{k}" missing or shape mismatch; using model default.')
            pdict[k] = model_dict[k]
    msg = encoder.load_state_dict(pdict, strict=False)
    logger.info(f'Loaded pretrained encoder with msg: {msg}')
    return encoder


def make_dataloader(
        root_path, batch_size, world_size, rank,
        dataset_type='VideoDataset', resolution=224,
        frames_per_clip=16, frame_step=1, num_segments=16,
        eval_duration=None, num_views_per_segment=1,
        allow_segment_overlap=True, training=False, num_workers=8, subset_file=None
):
    transform = make_transforms(
        training=training,
        num_views_per_clip=num_views_per_segment,
        random_horizontal_flip=False,
        random_resize_aspect_ratio=(0.8, 1.2),
        random_resize_scale=(0.7, 1.0),
        reprob=0.25,
        auto_augment=False,
        motion_shift=False,
        crop_size=resolution,
    )
    data_loader, _ = init_data(
        data=dataset_type,
        root_path=root_path,
        transform=transform,
        batch_size=batch_size,
        world_size=world_size,
        rank=rank,
        clip_len=frames_per_clip,
        frame_sample_rate=frame_step,
        duration=eval_duration,
        num_clips=num_segments,
        allow_clip_overlap=allow_segment_overlap,
        num_workers=num_workers,
        copy_data=False,
        drop_last=False,
        subset_file=subset_file
    )
    return data_loader


def init_model(
        device, pretrained, model_name,
        patch_size=16, crop_size=224,
        frames_per_clip=16, tubelet_size=2,
        use_sdpa=False, use_SiLU=False,
        tight_SiLU=True, uniform_power=False,
        checkpoint_key='target_encoder'
):
    encoder = vit.__dict__[model_name](
        img_size=crop_size,
        patch_size=patch_size,
        num_frames=frames_per_clip,
        tubelet_size=tubelet_size,
        uniform_power=uniform_power,
        use_sdpa=use_sdpa,
        use_SiLU=use_SiLU,
        tight_SiLU=tight_SiLU
    ).to(device)
    return load_pretrained(encoder=encoder, pretrained=pretrained, checkpoint_key=checkpoint_key)


def init_opt(
        classifier, encoder, iterations_per_epoch,
        start_lr, ref_lr, warmup, num_epochs,
        wd=1e-6, final_wd=1e-6, final_lr=0.0, use_bfloat16=False,
        qkv_adapter=None, qkv_lr=None  # LoRA适配器参数
):
    encoder_lr = 1e-6
    encoder_params = [p for n, p in encoder.named_parameters() if p.requires_grad]
    classifier_params = [p for n, p in classifier.named_parameters() if p.requires_grad]

    param_groups = [
        {"params": encoder_params, "lr": encoder_lr, "name": "encoder"},
        {"params": classifier_params, "lr": ref_lr, "name": "classifier"},
    ]

    # 加入LoRA适配器参数组
    if qkv_adapter is not None:
        if qkv_lr is None:
            qkv_lr = ref_lr  # 默认使用分类器学习率
        qkv_params = [p for p in qkv_adapter.parameters() if p.requires_grad]
        if len(qkv_params) > 0:
            param_groups.append({"params": qkv_params, "lr": qkv_lr, "name": "lora_adapter"})

    logger.info(
        "AdamW groups: " +
        f"encoder_lr={encoder_lr}, classifier_lr={ref_lr}" +
        (f", lora_lr={qkv_lr}" if qkv_adapter is not None else "")
    )

    optimizer = torch.optim.AdamW(param_groups, weight_decay=wd)

    scheduler = WarmupCosineSchedule(
        optimizer,
        warmup_steps=int(warmup * iterations_per_epoch),
        start_lr=start_lr,
        ref_lr=ref_lr,
        final_lr=final_lr,
        T_max=int(num_epochs * iterations_per_epoch),
    )
    wd_scheduler = CosineWDSchedule(
        optimizer,
        ref_wd=wd,
        final_wd=final_wd,
        T_max=int(num_epochs * iterations_per_epoch),
    )
    scaler = torch.amp.GradScaler() if use_bfloat16 else None
    return optimizer, scaler, scheduler, wd_scheduler