# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

import os
import time
import logging
import pprint
from pathlib import Path

import numpy as np
import torch
import torch.multiprocessing as mp
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel
from torch import nn
from torch.utils.data import DataLoader, Dataset
from PIL import Image
from torchvision import transforms

from sklearn.metrics import cohen_kappa_score

import src.models.vision_transformer as vit
from src.models.attentive_pooler import AttentiveClassifier
from src.datasets.data_manager import init_data
from src.utils.distributed import init_distributed, AllReduce
from src.utils.schedulers import WarmupCosineSchedule, CosineWDSchedule
from src.utils.logging import AverageMeter, CSVLogger
from evals.video_classification_frozen.utils import make_transforms, ClipAggregation, FrameAggregation
os.environ['NUMEXPR_MAX_THREADS'] = '16'

class CollateWithPath:
    """Top‐level collate_fn: 用 orig_collate 打包前三项，再附加 paths 列表。"""

    def __init__(self, orig_collate):
        self.orig_collate = orig_collate

    def __call__(self, batch):
        clips, labels, clip_idx, paths = zip(*batch)
        b_clips, b_labels, b_clip_idx = self.orig_collate(
            list(zip(clips, labels, clip_idx))
        )
        return b_clips, b_labels, b_clip_idx, list(paths)


class DatasetWithPath(Dataset):
    def __init__(self, orig_ds, image_root):
        self.orig_ds = orig_ds
        self.image_root = Path(image_root)

    def __len__(self):
        return len(self.orig_ds)

    def __getitem__(self, idx):
        clips, label, clip_idx = self.orig_ds[idx]

        # 直接从 samples 获取完整路径，避免CSV解析
        sample = self.orig_ds.samples[idx]
        video_path = sample[0] if isinstance(sample, (tuple, list)) else sample

        # 取文件名前4个字符作为图像前缀
        video_prefix = Path(video_path).stem[:4]

        return clips, label, clip_idx, video_prefix


logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

_GLOBAL_SEED = 0
np.random.seed(_GLOBAL_SEED)
torch.manual_seed(_GLOBAL_SEED)
torch.backends.cudnn.benchmark = True  # Enable cuDNN auto-tuning

pp = pprint.PrettyPrinter(indent=4)


def load_pretrained(encoder, pretrained, checkpoint_key='target_encoder'):
    logger.info(f'Loading pretrained model from {pretrained}')
    ckpt = torch.load(pretrained, map_location='cpu')
    pdict = ckpt.get(checkpoint_key, ckpt.get('encoder', {}))
    pdict = {k.replace('module.', '').replace('backbone.', ''): v for k, v in pdict.items()}
    model_dict = encoder.state_dict()
    for k in list(model_dict.keys()):
        if k not in pdict or pdict[k].shape != model_dict[k].shape:
            logger.info(f'Key "{k}" missing or shape mismatch; using default.')
            pdict[k] = model_dict[k]
    msg = encoder.load_state_dict(pdict, strict=False)
    logger.info(f'Loaded pretrained encoder with msg: {msg}')
    return encoder


def init_model(device, pretrained, model_name,
               patch_size=16, crop_size=224,
               frames_per_clip=16, tubelet_size=2,
               use_sdpa=False, use_SiLU=False,
               tight_SiLU=True, uniform_power=False,
               checkpoint_key='target_encoder'):
    encoder = vit.__dict__[model_name](img_size=crop_size, patch_size=patch_size, num_frames=frames_per_clip,
                                       tubelet_size=tubelet_size, uniform_power=uniform_power, use_sdpa=use_sdpa,
                                       use_SiLU=use_SiLU, tight_SiLU=tight_SiLU).to(device)
    return load_pretrained(encoder, pretrained, checkpoint_key)


def count_trainable_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


class LightUNet(nn.Module):
    """Lightweight UNet producing a feature vector of size out_channels."""

    def __init__(self, in_channels=3, base_channels=32, out_channels=64):
        super().__init__()
        # encoder
        self.enc1 = nn.Sequential(
            nn.Conv2d(in_channels, base_channels, 3, padding=1), nn.ReLU(),
            nn.Conv2d(base_channels, base_channels, 3, padding=1), nn.ReLU()
        )
        self.pool1 = nn.MaxPool2d(2)
        self.enc2 = nn.Sequential(
            nn.Conv2d(base_channels, base_channels * 2, 3, padding=1), nn.ReLU(),
            nn.Conv2d(base_channels * 2, base_channels * 2, 3, padding=1), nn.ReLU()
        )
        # decoder
        self.up1 = nn.ConvTranspose2d(base_channels * 2, base_channels, 2, stride=2)
        self.dec1 = nn.Sequential(
            nn.Conv2d(base_channels * 2, base_channels, 3, padding=1), nn.ReLU(),
            nn.Conv2d(base_channels, base_channels, 3, padding=1), nn.ReLU()
        )
        # final conv to out_channels
        self.final = nn.Conv2d(base_channels, out_channels, 1)
        # global pooling
        self.gap = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        e1 = self.enc1(x)  # [B, C, H, W]
        p1 = self.pool1(e1)  # [B, 2C, H/2, W/2]
        e2 = self.enc2(p1)  # [B, 2C, H/2, W/2]
        u1 = self.up1(e2)  # [B, C, H, W]
        cat = torch.cat([u1, e1], dim=1)  # [B, 2C, H, W]
        d1 = self.dec1(cat)  # [B, C, H, W]
        out = self.final(d1)  # [B, out_channels, H, W]
        vec = self.gap(out).flatten(1)  # [B, out_channels]
        return vec


def make_image_transform(resolution):
    """Creates a standard transform for validation/inference."""
    return transforms.Compose([
        transforms.Resize((resolution, resolution)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])


def make_augmented_image_transform(resolution):
    """Creates a transform with random augmentations for training."""
    return transforms.Compose([
        transforms.RandomResizedCrop(resolution, scale=(0.8, 1.0), ratio=(0.75, 1.333)),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])


def load_checkpoint(device, r_path, classifier, opt, scaler):
    try:
        ckpt = torch.load(r_path, map_location='cpu')
        epoch = ckpt.get('epoch', 0)
        classifier.load_state_dict(ckpt['classifier'])
        opt.load_state_dict(ckpt['opt'])
        if scaler:
            scaler.load_state_dict(ckpt['scaler'])
        logger.info(f'Loaded checkpoint from {r_path} (epoch {epoch})')
    except Exception as e:
        logger.info(f'Error loading checkpoint: {e}')
        epoch = 0
    return classifier, opt, scaler, epoch


def make_dataloader(
        root_path, batch_size, world_size, rank,
        dataset_type='VideoDataset', resolution=224,
        frames_per_clip=16, frame_step=1, num_segments=16,
        eval_duration=None, num_views_per_segment=1,
        allow_segment_overlap=True, training=False,
        num_workers=8, subset_file=None, image_root=None
):
    # 1) transforms 保持原样
    transform = make_transforms(
        training=training,
        num_views_per_clip=num_views_per_segment,
        random_horizontal_flip=False,
        random_resize_aspect_ratio=(0.75, 4 / 3),
        random_resize_scale=(0.8, 1.0),
        reprob=0.25,
        auto_augment=False,
        motion_shift=False,
        crop_size=resolution,
    )

    # 2) init_data：强制 single‐GPU 设置
    orig_loader, _ = init_data(
        data=dataset_type,
        root_path=root_path,
        transform=transform,
        batch_size=batch_size,
        world_size=1,  # 单 GPU
        rank=0,
        clip_len=frames_per_clip,
        frame_sample_rate=frame_step,
        duration=eval_duration,
        num_clips=num_segments,
        allow_clip_overlap=allow_segment_overlap,
        num_workers=8,  # single‐process
        copy_data=False,
        drop_last=False,
        subset_file=subset_file
    )

    # 3) 真正的底层 dataset
    base_ds = orig_loader.dataset

    # 4) 包装 dataset：从 CSV 或 base_ds 自带属性 读取路径
    csv_file = root_path[0] if isinstance(root_path, (list, tuple)) else root_path
    wrapped_ds = DatasetWithPath(base_ds, image_root=image_root)

    # 5) 复用 sampler & collate_fn
    sampler = orig_loader.sampler
    orig_collate = orig_loader.collate_fn
    collator = CollateWithPath(orig_collate)

    # 6) 最终 DataLoader：num_workers=0, pin_memory=False
    dl = DataLoader(
        wrapped_ds,
        batch_size=batch_size,
        sampler=sampler,
        num_workers=8,
        pin_memory=False,
        collate_fn=collator,
    )
    return dl


def main(args_eval, resume_preempt=False):
    # -------- Extract parameters --------
    args_pretrain = args_eval.get('pretrain', {})
    checkpoint_key = args_pretrain.get('checkpoint_key', 'target_encoder')
    model_name = args_pretrain.get('model_name')
    patch_size = args_pretrain.get('patch_size')
    pretrain_folder = args_pretrain.get('folder')
    ckp_fname = args_pretrain.get('checkpoint')
    tag = args_pretrain.get('write_tag')
    use_sdpa = args_pretrain.get('use_sdpa', True)
    use_SiLU = args_pretrain.get('use_silu', False)
    tight_SiLU = args_pretrain.get('tight_silu', True)
    uniform_power = args_pretrain.get('uniform_power', False)
    pretrained_path = os.path.join(pretrain_folder, ckp_fname)
    tubelet_size = args_pretrain.get('tubelet_size', 2)
    pretrain_frames_per_clip = args_pretrain.get('frames_per_clip', 1)

    args_data = args_eval.get('data', {})
    train_data_path = [args_data.get('dataset_train')]
    val_data_path = [args_data.get('dataset_val')]
    # --- Get image_root from config ---
    image_root = args_data.get('image_root')
    if image_root is None:
        raise ValueError("image_root not specified in config. Please add data.image_root to your config file.")
    image_root = Path(image_root)

    dataset_type = args_data.get('dataset_type', 'VideoDataset')
    num_classes = args_data.get('num_classes')
    eval_num_segments = args_data.get('num_segments', 16)
    eval_frames_per_clip = args_data.get('frames_per_clip', 16)
    eval_frame_step = args_pretrain.get('frame_step', 1)
    eval_duration = args_pretrain.get('clip_duration')
    eval_num_views_per_segment = args_data.get('num_views_per_segment', 1)

    args_opt = args_eval.get('optimization', {})
    resolution = args_opt.get('resolution', 224)
    batch_size = args_opt.get('batch_size')
    attend_across_segments = args_opt.get('attend_across_segments', False)
    num_epochs = args_opt.get('num_epochs')
    wd = args_opt.get('weight_decay')
    start_lr = args_opt.get('start_lr')
    lr = args_opt.get('lr')
    final_lr = args_opt.get('final_lr')
    warmup = args_opt.get('warmup')
    use_bfloat16 = args_opt.get('use_bfloat16', False)

    resume_checkpoint = args_eval.get('resume_checkpoint', False) or resume_preempt

    try:
        mp.set_start_method('spawn')
    except RuntimeError:
        pass

    device = torch.device('cuda:0') if torch.cuda.is_available() else torch.device('cpu')
    if device.type == 'cuda':
        torch.cuda.set_device(device)

    world_size, rank = init_distributed()
    logger.info(f'Initialized (rank/world-size) {rank}/{world_size}')

    os.makedirs(pretrain_folder, exist_ok=True)
    log_file = os.path.join(pretrain_folder, f'{tag}_r{rank}.csv')
    latest_path = os.path.join(pretrain_folder, f'{tag}-latest.pth.tar')
    if rank == 0:
        csv_logger = CSVLogger(log_file,
                               ('%d', 'epoch'),
                               ('%.5f', 'loss'),
                               ('%.5f', 'acc'),
                               ('%.5f', 'kappa_train'),
                               ('%.5f', 'kappa_val'))

    # --- Video encoder init & freeze ---
    encoder = init_model(
        crop_size=resolution, device=device,
        pretrained=pretrained_path, model_name=model_name,
        patch_size=patch_size, tubelet_size=tubelet_size,
        frames_per_clip=pretrain_frames_per_clip,
        uniform_power=uniform_power,
        checkpoint_key=checkpoint_key,
        use_SiLU=use_SiLU, tight_SiLU=tight_SiLU, use_sdpa=use_sdpa)
    if pretrain_frames_per_clip == 1:
        encoder = FrameAggregation(encoder).to(device)
    else:
        encoder = ClipAggregation(
            encoder, tubelet_size=tubelet_size,
            attend_across_segments=attend_across_segments).to(device)
    for p in encoder.parameters(): p.requires_grad = False
    for name, p in encoder.named_parameters():
        if any(f"blocks.{i}." in name for i in range(22, 24)) or ".norm" in name:
            p.requires_grad = True

    # --- Light UNet for images ---
    video_dim = encoder.embed_dim  # 1024
    img_dim = video_dim // 4  # 256
    unet = LightUNet(in_channels=3, base_channels=32, out_channels=img_dim).to(device)

    # --- Classifier accepts video_dim+img_dim (特征维度拼接) ---
    classifier = AttentiveClassifier(
        embed_dim=video_dim + img_dim,  # 1024 + 256 = 1280
        num_heads=encoder.num_heads,
        depth=1,
        num_classes=num_classes).to(device)

    # Count params
    enc_params = count_trainable_parameters(encoder)
    unet_params = count_trainable_parameters(unet)
    cls_params = count_trainable_parameters(classifier)
    total_params = enc_params + unet_params + cls_params
    logger.info(
        f"Trainable params: encoder={enc_params:,}, unet={unet_params:,}, classifier={cls_params:,}, total={total_params:,}")

    # --- Image transforms ---
    img_transform_train = make_augmented_image_transform(resolution)
    img_transform_val = make_image_transform(resolution)

    # Data loaders
    train_loader = make_dataloader(
        dataset_type=dataset_type, root_path=train_data_path,
        resolution=resolution, frames_per_clip=eval_frames_per_clip,
        frame_step=eval_frame_step, eval_duration=eval_duration,
        num_segments=eval_num_segments if attend_across_segments else 1,
        num_views_per_segment=1, allow_segment_overlap=True,
        batch_size=batch_size, world_size=world_size,
        rank=rank, training=True, image_root=image_root)

    val_loader = make_dataloader(
        dataset_type=dataset_type, root_path=val_data_path,
        resolution=resolution, frames_per_clip=eval_frames_per_clip,
        frame_step=eval_frame_step, num_segments=eval_num_segments,
        eval_duration=eval_duration, num_views_per_segment=eval_num_views_per_segment,
        allow_segment_overlap=True, batch_size=batch_size,
        world_size=world_size, rank=rank, training=False, image_root=image_root)

    iterations = len(train_loader)
    optimizer, scaler, scheduler, wd_scheduler = init_opt(
        classifier=classifier, encoder=encoder,
        unet=unet, wd=wd,
        start_lr=start_lr, ref_lr=lr,
        final_lr=final_lr, iterations_per_epoch=iterations,
        warmup=warmup, num_epochs=num_epochs,
        use_bfloat16=use_bfloat16)

    start_epoch = 0
    if resume_checkpoint:
        classifier, optimizer, scaler, start_epoch = load_checkpoint(
            device=device, r_path=latest_path,
            classifier=classifier, opt=optimizer, scaler=scaler)
        for _ in range(start_epoch * iterations):
            scheduler.step();
            wd_scheduler.step()
            for g in optimizer.param_groups:
                if g.get("name") == "encoder":
                    g["lr"] = 1e-6

    # Training loop
    for epoch in range(start_epoch, num_epochs):
        t0 = time.time()
        logger.info(f"Epoch {epoch + 1}/{num_epochs} start")

        train_acc, train_preds, train_labels = run_one_epoch(
            device=device, training=True,
            attend_across_segments=attend_across_segments,
            encoder=encoder, unet=unet, classifier=classifier,
            scaler=scaler, optimizer=optimizer,
            scheduler=scheduler, wd_scheduler=wd_scheduler,
            data_loader=train_loader,
            img_transform=img_transform_train,
            image_root=image_root,
            use_bfloat16=use_bfloat16,
            img_dim=img_dim)

        train_kappa = cohen_kappa_score(train_labels, train_preds)

        # Validation
        val_acc, val_kappa = 0.0, 0.0
        if epoch + 1 > 1:
            val_acc, val_preds, val_labels = run_one_epoch(
                device=device, training=False,
                attend_across_segments=attend_across_segments,
                encoder=encoder, unet=unet, classifier=classifier,
                scaler=scaler, optimizer=optimizer,
                scheduler=scheduler, wd_scheduler=wd_scheduler,
                data_loader=val_loader,
                img_transform=img_transform_val,
                image_root=image_root,
                use_bfloat16=use_bfloat16,
                img_dim=img_dim)
            val_kappa = cohen_kappa_score(val_labels, val_preds)
            logger.info(f"[Val] Acc: {val_acc:.3f}%  Kappa: {val_kappa:.5f}")

        if rank == 0:
            csv_logger.log(epoch + 1, train_acc, val_acc, train_kappa, val_kappa)
        logger.info(f"Epoch {epoch + 1} done in {time.time() - t0:.2f}s")

        # Save encoder and unet



def run_one_epoch(
        device, training, attend_across_segments,
        encoder, unet, classifier,
        scaler, optimizer, scheduler, wd_scheduler,
        data_loader, img_transform, image_root: Path,
        use_bfloat16, img_dim
):
    encoder.train() if training else encoder.eval()
    unet.train() if training else unet.eval()
    classifier.train() if training else classifier.eval()

    criterion = nn.CrossEntropyLoss()
    meter = AverageMeter()
    all_preds, all_labels = [], []

    for itr, (clips, labels, clip_idx, paths) in enumerate(data_loader):
        if training:
            scheduler.step()
            wd_scheduler.step()

        labels = labels.to(device)
        B = labels.size(0)

        with torch.amp.autocast('cuda', enabled=use_bfloat16):
            # --- Video features ---
            clips_dev = [[d.to(device) for d in seq] for seq in clips]
            clip_idx_dev = [c.to(device) for c in clip_idx]
            if training:
                vid_feats = encoder(clips_dev, clip_idx_dev)
            else:
                with torch.no_grad():
                    vid_feats = encoder(clips_dev, clip_idx_dev)

            # 处理视频特征：保持3D结构 [B, seq_len, video_dim]
            if attend_across_segments:
                # 如果跨segment注意力，保持原始结构
                vid_feats = torch.stack(vid_feats, 0).mean(0)  # 在segment维度平均
            else:
                # 处理嵌套列表结构
                if isinstance(vid_feats, list):
                    segment_feats = []
                    for s in vid_feats:
                        if isinstance(s, list):
                            segment_feat = torch.stack(s, 0).mean(0)
                        else:
                            segment_feat = s
                        segment_feats.append(segment_feat)
                    vid_feats = torch.stack(segment_feats, 0).mean(0)
                else:
                    # 如果已经是tensor，确保是3D
                    if vid_feats.dim() == 2:
                        vid_feats = vid_feats.unsqueeze(1)  # [B, 1, dim]

            # 确保vid_feats是3D: [B, seq_len, video_dim]
            if vid_feats.dim() == 2:
                vid_feats = vid_feats.unsqueeze(1)  # [B, 1, video_dim]

            # --- Image features ---
            img_tensors = []
            for i, video_prefix in enumerate(paths):
                # 查找匹配的图像文件
                image_extensions = ['.jpg', '.jpeg', '.png', '.JPG', '.JPEG', '.PNG']
                img_path = None
                for ext in image_extensions:
                    potential_path = image_root / f"{video_prefix}{ext}"
                    if potential_path.exists():
                        img_path = potential_path
                        break

                if img_path is None:
                    if itr % 20 == 0:  # 减少重复输出
                        print(f"ERROR: 找不到前缀为 {video_prefix} 的图片文件 at {image_root}")
                    # 创建默认黑色图片
                    img = Image.new('RGB', (224, 224), color='black')
                    img_tensors.append(img_transform(img))
                else:
                    img = Image.open(img_path).convert("RGB")
                    img_tensors.append(img_transform(img))

            imgs = torch.stack(img_tensors, 0).to(device)
            img_feats = unet(imgs)  # [B, img_dim]

            # --- 特征维度拼接 ---
            B, seq_len, video_dim = vid_feats.shape

            # 扩展图片特征到视频序列长度
            img_feats_expanded = img_feats.unsqueeze(1).repeat(1, seq_len, 1)  # [B, seq_len, img_dim]

            # 在特征维度拼接
            fused_feats = torch.cat([vid_feats, img_feats_expanded], dim=2)  # [B, seq_len, video_dim + img_dim]

            if itr % 20 == 0:
                print(f"DEBUG: vid_feats shape: {vid_feats.shape}")
                print(f"DEBUG: img_feats_expanded shape: {img_feats_expanded.shape}")
                print(f"DEBUG: fused_feats shape: {fused_feats.shape}")

            # 输入到分类器
            outputs = classifier(fused_feats)
            loss = criterion(outputs, labels)

        # --- Accuracy ---
        with torch.no_grad():
            probs = F.softmax(outputs, dim=1)
            preds = probs.argmax(1).cpu().numpy()
            true = labels.cpu().numpy()
            all_preds.append(preds)
            all_labels.append(true)
            acc = 100. * (preds == true).sum() / B
            meter.update(float(AllReduce.apply(acc)))

        # --- Backward ---
        if training:
            if use_bfloat16:
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(encoder.parameters(), 0.2)
                torch.nn.utils.clip_grad_norm_(unet.parameters(), 0.2)
                torch.nn.utils.clip_grad_norm_(classifier.parameters(), 1.0)
                scaler.step(optimizer)
                scaler.update()
            else:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(encoder.parameters(), 0.2)
                torch.nn.utils.clip_grad_norm_(unet.parameters(), 0.2)
                torch.nn.utils.clip_grad_norm_(classifier.parameters(), 1.0)
                optimizer.step()
            optimizer.zero_grad()

        if itr % 20 == 0:
            print(f"[{itr:5d}] {meter.avg:.3f}% loss:{loss:.3f}")

    all_preds = np.concatenate(all_preds)
    all_labels = np.concatenate(all_labels)
    return meter.avg, all_preds, all_labels


def init_opt(classifier, encoder, unet,
             iterations_per_epoch,
             start_lr, ref_lr, warmup, num_epochs,
             wd=1e-6, final_wd=1e-6, final_lr=0.0,
             use_bfloat16=False):
    # param groups: encoder (low lr), unet (mid lr), classifier (ref_lr)
    enc_lr = 1e-6
    unet_lr = ref_lr / 2
    groups = [
        {"params": [p for p in encoder.parameters() if p.requires_grad], "lr": enc_lr, "name": "encoder"},
        {"params": [p for p in unet.parameters() if p.requires_grad], "lr": unet_lr, "name": "unet"},
        {"params": [p for p in classifier.parameters() if p.requires_grad], "lr": ref_lr, "name": "classifier"},
    ]
    optimizer = torch.optim.AdamW(groups, weight_decay=wd)
    scheduler = WarmupCosineSchedule(
        optimizer, warmup_steps=int(warmup * iterations_per_epoch),
        start_lr=start_lr, ref_lr=ref_lr,
        final_lr=final_lr,
        T_max=int(num_epochs * iterations_per_epoch))
    wd_scheduler = CosineWDSchedule(
        optimizer, ref_wd=wd, final_wd=final_wd,
        T_max=int(num_epochs * iterations_per_epoch))
    scaler = torch.amp.GradScaler() if use_bfloat16 else None
    return optimizer, scaler, scheduler, wd_scheduler
