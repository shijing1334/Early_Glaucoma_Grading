# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
import os
import time
import logging
import pprint
import pickle
import pandas as pd

import numpy as np
import torch
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel

import src.models.vision_transformer as vit
from src.models.attentive_pooler import AttentiveClassifier
from src.datasets.data_manager import init_data
from src.utils.schedulers import WarmupCosineSchedule, CosineWDSchedule
from src.utils.logging import AverageMeter, CSVLogger
from evals.video_classification_frozen.utils import make_transforms, ClipAggregation, FrameAggregation

# 导入级联预测模块
from cascade_predictor_hxjz import CascadePredictor

os.environ['NUMEXPR_MAX_THREADS'] = '16'
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

_GLOBAL_SEED = 0
np.random.seed(_GLOBAL_SEED)
torch.manual_seed(_GLOBAL_SEED)
torch.backends.cudnn.benchmark = False
torch.cuda.manual_seed_all(_GLOBAL_SEED)
os.environ['PYTHONHASHSEED'] = str(_GLOBAL_SEED)

pp = pprint.PrettyPrinter(indent=4)

def multilabel_to_three_class(pred_probs, thresholds=(0.5, 0.5, 0.5)):
    """
    将三个二分类任务的概率(pred_non2, pred_non0, pred_non1)转换为最终三分类预测(0/1/2)。

    任务含义(与convert_labels_to_multi一致):
      t0: non2 = 1 表示不是2 (即 {0,1})
      t1: non0 = 1 表示不是0 (即 {1,2})
      t2: non1 = 1 表示不是1 (即 {0,2})

    规则：先阈值得到三位布尔，再做一致性判断；不一致时用“证据计分”选最可能类别。
    """
    # pred_probs: [B,3] in (0,1)
    t0, t1, t2 = thresholds
    b0 = pred_probs[:, 0] > t0  # non2
    b1 = pred_probs[:, 1] > t1  # non0
    b2 = pred_probs[:, 2] > t2  # non1

    # 一致性模式：
    # class0: non2=1, non0=0, non1=1  => (1,0,1)
    # class1: non2=1, non0=1, non1=0  => (1,1,0)
    # class2: non2=0, non0=1, non1=1  => (0,1,1)
    final = torch.full((pred_probs.size(0),), -1, device=pred_probs.device, dtype=torch.long)

    m0 = b0 & (~b1) & b2
    m1 = b0 & b1 & (~b2)
    m2 = (~b0) & b1 & b2
    final[m0] = 0
    final[m1] = 1
    final[m2] = 2

    # 对不一致样本：给每个class一个“支持度”分数（越大越可能）
    # 支持度定义为：满足该class应为1的任务取 p，应该为0的任务取 (1-p)，三项相加
    unresolved = final < 0
    if unresolved.any():
        p0 = pred_probs[:, 0]
        p1 = pred_probs[:, 1]
        p2 = pred_probs[:, 2]

        score_c0 = p0 + (1 - p1) + p2        # (1,0,1)
        score_c1 = p0 + p1 + (1 - p2)        # (1,1,0)
        score_c2 = (1 - p0) + p1 + p2        # (0,1,1)
        scores = torch.stack([score_c0, score_c1, score_c2], dim=1)  # [B,3]
        final[unresolved] = torch.argmax(scores[unresolved], dim=1)

    return final
def count_trainable_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def convert_labels_to_multi(original_labels):
    """
    Convert original 3-class labels (0,1,2) to multi-label binary (3 tasks)
    - Label 0 (非2): 1 if original label in [0,1], 0 otherwise
    - Label 1 (非0): 1 if original label in [1,2], 0 otherwise
    - Label 2 (非1): 1 if original label in [0,2], 0 otherwise

    Returns:
    - multi_labels: [batch_size, 3] tensor
    """
    batch_size = original_labels.size(0)
    multi_labels = torch.zeros(batch_size, 3, device=original_labels.device)

    # Label 0: 非2 (not class 2) -> original classes 0,1
    multi_labels[:, 0] = ((original_labels == 0) | (original_labels == 1)).float()

    # Label 1: 非0 (not class 0) -> original classes 1,2
    multi_labels[:, 1] = ((original_labels == 1) | (original_labels == 2)).float()

    # Label 2: 非1 (not class 1) -> original classes 0,2
    multi_labels[:, 2] = ((original_labels == 0) | (original_labels == 2)).float()

    return multi_labels


def extract_video_name(path):
    """Extract video name from path for matching"""
    if isinstance(path, str):
        return os.path.basename(path).split('.')[0]  # 去掉扩展名
    return str(path)


def main(args_eval, resume_preempt=False, top_k_thresholds=20):
    # -------- Extract parameters --------
    args_pretrain = args_eval.get('pretrain', {})
    checkpoint_key = args_pretrain.get('checkpoint_key', 'target_encoder')
    model_name = args_pretrain.get('model_name')
    patch_size = args_pretrain.get('patch_size')
    pretrain_folder = args_pretrain.get('folder')
    ckp_fname = args_pretrain.get('checkpoint')
    tag = args_pretrain.get('write_tag')
    use_sdpa = args_pretrain.get('use_sdpa', True)
    use_SiLU = args_pretrain.get('use_silu', False)
    tight_SiLU = args_pretrain.get('tight_silu', True)
    uniform_power = args_pretrain.get('uniform_power', False)
    # 只有预训练模型路径使用 pretrain_folder
    pretrained_path = os.path.join(pretrain_folder, ckp_fname) if pretrain_folder and ckp_fname else None
    tubelet_size = args_pretrain.get('tubelet_size', 2)
    pretrain_frames_per_clip = args_pretrain.get('frames_per_clip', 1)

    # 从配置读取权重路径（独立的相对/绝对路径）
    encoder_weights_path = args_pretrain.get('encoder_weights', 'encoder_epoch_23.pth')
    classifier_weights_path = args_pretrain.get('classifier_weights', 'classifier_epoch_23.pth')

    args_data = args_eval.get('data', {})
    train_data_path = [args_data.get('dataset_train')]
    val_data_path = [args_data.get('dataset_val')]
    dataset_type = args_data.get('dataset_type', 'VideoDataset')
    num_classes = args_data.get('num_classes')
    eval_num_segments = args_data.get('num_segments', 16)
    eval_frames_per_clip = args_data.get('frames_per_clip', 16)
    eval_frame_step = args_pretrain.get('frame_step', 1)
    eval_duration = args_pretrain.get('clip_duration')
    eval_num_views_per_segment = args_data.get('num_views_per_segment', 1)

    args_opt = args_eval.get('optimization', {})
    resolution = args_opt.get('resolution', 224)
    batch_size = args_opt.get('batch_size')
    attend_across_segments = args_opt.get('attend_across_segments', False)
    num_epochs = args_opt.get('num_epochs', 1)  # 运行的epoch数
    wd = args_opt.get('weight_decay')
    start_lr = args_opt.get('start_lr')
    lr = args_opt.get('lr')
    final_lr = args_opt.get('final_lr')
    warmup = args_opt.get('warmup')
    use_bfloat16 = args_opt.get('use_bfloat16', False)

    # Cascade prediction配置（独立的相对/绝对路径）
    cascade_config = args_eval.get('cascade', {})
    three_class_model_path = cascade_config.get('three_class_model_path', 'best_model.pth')
    three_class_csv_path = cascade_config.get('three_class_csv_path', 'val_image.csv')
    selected_model = cascade_config.get('selected_model', 'best_efficientnet_b3_seed_125')

    # 读取阈值列表（直接使用配置文件中的固定值）
    cascade_thresholds = cascade_config.get('cascade_thresholds', [0.8, 0.8, 0.8])

    # 兼容旧阈值参数
    if 'threshold_non2' in cascade_config or 'threshold_non0' in cascade_config or 'threshold_non1' in cascade_config:
        logger.warning("发现旧的阈值参数。请使用 'cascade_thresholds' 列表格式。")
        cascade_thresholds = [
            cascade_config.get('threshold_non2', 0.0),
            cascade_config.get('threshold_non0', 0.0),
            cascade_config.get('threshold_non1', 0.0)
        ]

    # 创建权重保存目录（仅用于记录，不会保存新权重）
    if pretrain_folder:
        weights_dir = os.path.join(pretrain_folder, 'weights')
        logger.info(f"预训练权重目录: {weights_dir}")

    # 解析并验证所有路径（转换为绝对路径便于日志显示）
    encoder_weights_abs = os.path.abspath(encoder_weights_path)
    classifier_weights_abs = os.path.abspath(classifier_weights_path)
    three_class_model_abs = os.path.abspath(three_class_model_path)
    three_class_csv_abs = os.path.abspath(three_class_csv_path)

    # 打印路径信息，方便调试
    logger.info(f"编码器权重路径: {encoder_weights_abs} (原始配置: {encoder_weights_path})")
    logger.info(f"分类器权重路径: {classifier_weights_abs} (原始配置: {classifier_weights_path})")
    logger.info(f"三分类模型路径: {three_class_model_abs} (原始配置: {three_class_model_path})")
    logger.info(f"三分类CSV路径: {three_class_csv_abs} (原始配置: {three_class_csv_path})")

    device = torch.device('cuda:0') if torch.cuda.is_available() else torch.device('cpu')
    if device.type == 'cuda':
        torch.cuda.set_device(device)

    # 创建用于日志的文件夹
    if pretrain_folder:
        os.makedirs(pretrain_folder, exist_ok=True)
        log_file = os.path.join(pretrain_folder, f'{tag}_inference.csv')
    else:
        # 如果没有pretrain_folder，日志文件保存在当前目录
        log_file = f'{tag}_inference.csv'

    # 初始化 cascade predictor（使用配置文件中的固定阈值）
    cascade_predictor = CascadePredictor(
        model_path=three_class_model_path,  # 使用原始路径（支持相对/绝对）
        csv_path=three_class_csv_path,  # 使用原始路径（支持相对/绝对）
        selected_model=selected_model,
        device=device,
        cascade_thresholds=cascade_thresholds
    )
    logger.info(f"Cascade predictor initialized with fixed thresholds: {cascade_thresholds}")
    fixed_thresholds = (
        cascade_predictor.threshold_non2,
        cascade_predictor.threshold_non0,
        cascade_predictor.threshold_non1
    )
    logger.info(f"使用的固定阈值: non2={fixed_thresholds[0]}, non0={fixed_thresholds[1]}, non1={fixed_thresholds[2]}")

    # 初始化并冻结编码器
    if pretrained_path and os.path.exists(pretrained_path):
        encoder = init_model(
            crop_size=resolution,
            device=device,
            pretrained=pretrained_path,
            model_name=model_name,
            patch_size=patch_size,
            tubelet_size=tubelet_size,
            frames_per_clip=pretrain_frames_per_clip,
            uniform_power=uniform_power,
            checkpoint_key=checkpoint_key,
            use_SiLU=use_SiLU,
            tight_SiLU=tight_SiLU
        )
    else:
        logger.warning(f"预训练模型路径不存在: {pretrained_path}，使用随机初始化")
        encoder = init_model(
            crop_size=resolution,
            device=device,
            pretrained=None,
            model_name=model_name,
            patch_size=patch_size,
            tubelet_size=tubelet_size,
            frames_per_clip=pretrain_frames_per_clip,
            uniform_power=uniform_power,
            checkpoint_key=checkpoint_key,
            use_SiLU=use_SiLU,
            tight_SiLU=tight_SiLU
        )

    if pretrain_frames_per_clip == 1:
        encoder = FrameAggregation(encoder).to(device)
    else:
        encoder = ClipAggregation(
            encoder,
            tubelet_size=tubelet_size,
            attend_across_segments=attend_across_segments
        ).to(device)

    # 冻结所有参数
    for p in encoder.parameters():
        p.requires_grad = False

    # 初始化多标签分类器
    classifier = AttentiveClassifier(
        embed_dim=encoder.embed_dim,
        num_heads=encoder.num_heads,
        depth=1,
        num_classes=3,  # 三个任务的多标签分类
    ).to(device)

    # 记录可训练参数的总数（应为0）
    enc_params = count_trainable_parameters(encoder)
    cls_params = count_trainable_parameters(classifier)
    logger.info(f"Trainable encoder params: {enc_params:,}")
    logger.info(f"Trainable classifier params: {cls_params:,}")
    logger.info(f"Total trainable params: {enc_params + cls_params:,}")

    # 数据加载器 - 只需要验证集
    val_loader = make_dataloader(
        dataset_type=dataset_type,
        root_path=val_data_path,
        resolution=resolution,
        frames_per_clip=eval_frames_per_clip,
        frame_step=eval_frame_step,
        num_segments=eval_num_segments,
        eval_duration=eval_duration,
        num_views_per_segment=eval_num_views_per_segment,
        allow_segment_overlap=True,
        batch_size=batch_size,
        training=False
    )

    logger.info(f'Dataloader iterations per epoch: {len(val_loader)}')

    # 创建空的优化器和调度器（不会使用）
    optimizer, scaler, scheduler, wd_scheduler = None, None, None, None

    # 加载指定的权重文件
    logger.info(f"加载权重: {encoder_weights_path} 和 {classifier_weights_path}")
    # 增加文件存在性检查
    if not os.path.exists(encoder_weights_path):
        logger.error(f"编码器权重文件不存在: {encoder_weights_path} (绝对路径: {encoder_weights_abs})")
        raise FileNotFoundError(f"Encoder weights file not found: {encoder_weights_path}")
    if not os.path.exists(classifier_weights_path):
        logger.error(f"分类器权重文件不存在: {classifier_weights_path} (绝对路径: {classifier_weights_abs})")
        raise FileNotFoundError(f"Classifier weights file not found: {classifier_weights_path}")

    encoder.load_state_dict(torch.load(encoder_weights_path, map_location=device))
    classifier.load_state_dict(torch.load(classifier_weights_path, map_location=device))
    logger.info(f"成功加载权重文件")

    # 推理循环
    # 推理循环
    for epoch in range(num_epochs):
        epoch_start = time.time()
        logger.info(f'Starting inference epoch {epoch + 1}')

        # (1) 一阶段推理：得到二分类三任务概率 + 你当前的final_prediction(可被覆盖)
        val_acc_non2, val_acc_non0, val_acc_non1, val_predictions = run_one_epoch(
            device=device,
            training=False,
            num_temporal_views=eval_num_segments,
            attend_across_segments=attend_across_segments,
            num_spatial_views=eval_num_views_per_segment,
            encoder=encoder,
            classifier=classifier,
            scaler=scaler,
            optimizer=optimizer,
            scheduler=scheduler,
            wd_scheduler=wd_scheduler,
            data_loader=val_loader,
            use_bfloat16=use_bfloat16,
            save_predictions=True
        )

        logger.info(
            f'[Inference][Epoch {epoch + 1}] Acc_non2: {val_acc_non2:.3f}% | Acc_non0: {val_acc_non0:.3f}% | Acc_non1: {val_acc_non1:.3f}%'
        )

        # (2) 二阶段/级联：返回逐样本cascade_prediction（注意：CascadePredictor.predict 必须返回3个值）
        cascade_acc, cascade_kappa, cascade_rows = cascade_predictor.predict(val_predictions)
        logger.info(
            f'\n[Inference][Epoch {epoch + 1}] 固定阈值性能: '
            f'Thresholds(non2={fixed_thresholds[0]}, non0={fixed_thresholds[1]}, non1={fixed_thresholds[2]}) | '
            f'Acc={cascade_acc:.3f}% | Kappa={cascade_kappa:.4f}'
        )

        # (3) 保存CSV：用级联最终预测覆盖 final_prediction，再导出混淆矩阵CSV
        if val_predictions is not None and len(val_predictions) > 0:
            df_pred = pd.DataFrame(val_predictions)
            df_cascade = pd.DataFrame(cascade_rows)

            df_merged = df_pred.merge(
                df_cascade[["video_name", "cascade_prediction"]],
                on="video_name",
                how="left"
            )

            # 混淆矩阵用级联最终预测
            df_merged["final_prediction"] = df_merged["cascade_prediction"]

            pred_save_path = os.path.join(
                pretrain_folder if pretrain_folder else '.',
                f"{tag}_inference_epoch{epoch + 1}_val_predictions.csv"
            )
            df_merged.to_csv(pred_save_path, index=False)
            logger.info(f"Saved inference predictions for epoch {epoch + 1} to {pred_save_path}")

            cm_csv_path = os.path.join(
                pretrain_folder if pretrain_folder else '.',
                f"{tag}_confusion_matrix_data.csv"
            )
            df_merged[["true_label", "final_prediction"]].to_csv(cm_csv_path, index=False)
            logger.info(f"Saved confusion-matrix CSV to {cm_csv_path}")

        # (4) 记录主日志
        csv_logger = CSVLogger(
            log_file,
            ('%d', 'epoch'),
            ('%.5f', 'acc_non2_val'),
            ('%.5f', 'acc_non0_val'),
            ('%.5f', 'acc_non1_val'),
            ('%.5f', 'cascade_acc'),
            ('%.5f', 'cascade_kappa')
        )
        csv_logger.log(epoch + 1, val_acc_non2, val_acc_non0, val_acc_non1, cascade_acc, cascade_kappa)

        epoch_end = time.time()
        logger.info(f'Epoch {epoch + 1} duration: {epoch_end - epoch_start:.2f} seconds\n')


def run_one_epoch(
        device,
        training,
        encoder,
        classifier,
        scaler,
        optimizer,
        scheduler,
        wd_scheduler,
        data_loader,
        use_bfloat16,
        num_spatial_views,
        num_temporal_views,
        attend_across_segments,
        save_predictions=False
):
    import torch
    from collections import Counter
    import numpy as np
    from torch.nn import functional as F

    # 确保模型处于评估模式
    encoder.eval()
    classifier.eval()

    criterion = torch.nn.BCEWithLogitsLoss()
    acc_non2_meter = AverageMeter()
    acc_non0_meter = AverageMeter()
    acc_non1_meter = AverageMeter()

    # 用于预测保存
    predictions_data = []
    seen_labels = set()
    all_label_list = []

    for itr, data in enumerate(data_loader):
        with torch.no_grad():
            with torch.cuda.amp.autocast(dtype=torch.float16, enabled=use_bfloat16):
                clips = [
                    [dij.to(device, non_blocking=True) for dij in di]
                    for di in data[0]
                ]
                clip_indices = [d.to(device, non_blocking=True) for d in data[2]]
                original_labels = data[1].to(device)
                batch_size = original_labels.size(0)

                # 路径获取
                video_paths = []
                if len(data) > 3:
                    for i in range(3, len(data)):
                        if isinstance(data[i], (list, tuple)) and len(data[i]) > 0:
                            if isinstance(data[i][0], str):
                                video_paths = data[i]
                                break
                if not video_paths:
                    video_paths = [f"sample_{itr * batch_size + i}" for i in range(batch_size)]

                # 多标签处理
                multi_labels = convert_labels_to_multi(original_labels)

                unique = original_labels.unique().cpu().numpy().tolist()
                seen_labels.update(unique)
                all_label_list.extend(original_labels.cpu().numpy().tolist())

                outputs = encoder(clips, clip_indices)

                if attend_across_segments:
                    outputs_logits = [classifier(o) for o in outputs]
                else:
                    outputs_logits = [[classifier(o) for o in seq] for seq in outputs]

            # 损失计算（仅用于记录）
            if attend_across_segments:
                loss = sum(criterion(o, multi_labels) for o in outputs_logits) / len(outputs_logits)
            else:
                loss = sum(sum(criterion(o, multi_labels) for o in seq) for seq in outputs_logits) / (
                        len(outputs_logits) * len(outputs_logits[0]))

            with torch.no_grad():
                # 融合 batch 预测（计算平均logits）
                if attend_across_segments:
                    avg_logits = sum(o for o in outputs_logits) / len(outputs_logits)
                else:
                    avg_logits = sum(sum(o for o in seq) for seq in outputs_logits) / (
                            len(outputs_logits) * len(outputs_logits[0]))

                # 通过sigmoid将logits转换为0-1之间的概率
                pred_probs = torch.sigmoid(avg_logits)  # shape: [batch, 3]，值严格在(0,1)之间

                # 基于概率的预测（阈值0.5）
                predictions = pred_probs > 0.5

                true_multi = multi_labels.bool()

                # 保存预测结果
                if save_predictions:
                    for i in range(batch_size):
                        video_name = extract_video_name(video_paths[i] if i < len(video_paths) else f"sample_{i}")

                        # 调试：检查non0概率范围，确保在0-1之间
                        non0_score = pred_probs[i, 1].cpu().item()
                        if not (0 <= non0_score <= 1):
                            logger.warning(
                                f"non0概率异常: {non0_score:.4f} (视频: {video_name}, logit值: {avg_logits[i, 1].cpu().item():.4f})"
                            )

                        predictions_data.append({
                            'video_name': video_name,
                            'video_path': video_paths[i] if i < len(video_paths) else f"sample_{i}",
                            'true_label': original_labels[i].cpu().item(),
                            'final_prediction': -1,
                            'pred_non2_score': pred_probs[i, 0].cpu().item(),
                            'pred_non0_score': non0_score,
                            'pred_non1_score': pred_probs[i, 2].cpu().item(),
                            'true_non2': true_multi[i, 0].cpu().item(),
                            'true_non0': true_multi[i, 1].cpu().item(),
                            'true_non1': true_multi[i, 2].cpu().item()
                        })

                # 三任务独立准确率计算
                acc_non2 = 100. * (predictions[:, 0] == true_multi[:, 0]).float().sum() / batch_size
                acc_non2_meter.update(acc_non2)

                acc_non0 = 100. * (predictions[:, 1] == true_multi[:, 1]).float().sum() / batch_size
                acc_non0_meter.update(acc_non0)

                acc_non1 = 100. * (predictions[:, 2] == true_multi[:, 2]).float().sum() / batch_size
                acc_non1_meter.update(acc_non1)

        if itr % 20 == 0:
            logger.info(
                f'[{itr:5d}] Acc_non2: {acc_non2_meter.avg:.3f}% | Acc_non0: {acc_non0_meter.avg:.3f}% | Acc_non1: {acc_non1_meter.avg:.3f}% | '
                f'Loss: {loss:.3f} | Mem: {torch.cuda.max_memory_allocated() / 1024. ** 2:.2f} MB')

    logger.info(f"[Epoch End] Seen labels: {sorted(seen_labels)}; Counts: {dict(Counter(all_label_list))}")

    if save_predictions:
        return acc_non2_meter.avg, acc_non0_meter.avg, acc_non1_meter.avg, predictions_data
    else:
        return acc_non2_meter.avg, acc_non0_meter.avg, acc_non1_meter.avg


# 其他函数保持不变...
def load_checkpoint(device, r_path, classifier, opt, scaler):
    try:
        ckpt = torch.load(r_path, map_location='cpu')
        epoch = ckpt.get('epoch', 0)
        msg = classifier.load_state_dict(ckpt['classifier'])
        logger.info(f'Loaded classifier from epoch {epoch}: {msg}')
        opt.load_state_dict(ckpt['opt'])
        if scaler:
            scaler.load_state_dict(ckpt['scaler'])
        logger.info(f'Loaded optimizer/scaler from {r_path}')
    except Exception as e:
        logger.info(f'Error loading checkpoint: {e}')
        epoch = 0
    return classifier, opt, scaler, epoch


def load_pretrained(encoder, pretrained, checkpoint_key='target_encoder'):
    if not pretrained:
        logger.info("未指定预训练模型路径，使用随机初始化")
        return encoder

    logger.info(f'Loading pretrained model from {pretrained}')
    ckpt = torch.load(pretrained, map_location='cpu')
    pdict = ckpt.get(checkpoint_key, ckpt.get('encoder', {}))
    pdict = {k.replace('module.', '').replace('backbone.', ''): v for k, v in pdict.items()}
    model_dict = encoder.state_dict()
    for k in list(model_dict.keys()):
        if k not in pdict or pdict[k].shape != model_dict[k].shape:
            logger.info(f'Key "{k}" missing or shape mismatch; using model default.')
            pdict[k] = model_dict[k]
    msg = encoder.load_state_dict(pdict, strict=False)
    logger.info(f'Loaded pretrained encoder with msg: {msg}')
    return encoder


def make_dataloader(
        root_path, batch_size,
        dataset_type='VideoDataset', resolution=224,
        frames_per_clip=16, frame_step=1, num_segments=16,
        eval_duration=None, num_views_per_segment=1,
        allow_segment_overlap=True, training=False, num_workers=8, subset_file=None
):
    transform = make_transforms(
        training=training,
        num_views_per_clip=num_views_per_segment,
        random_horizontal_flip=False,
        random_resize_aspect_ratio=(1, 1),
        random_resize_scale=(1, 1.0),
        reprob=0.25,
        auto_augment=False,
        motion_shift=False,
        crop_size=resolution,
    )
    data_loader, _ = init_data(
        data=dataset_type,
        root_path=root_path,
        transform=transform,
        batch_size=batch_size,
        clip_len=frames_per_clip,
        frame_sample_rate=frame_step,
        duration=eval_duration,
        num_clips=num_segments,
        allow_clip_overlap=allow_segment_overlap,
        num_workers=num_workers,
        copy_data=False,
        drop_last=False,
        subset_file=subset_file
    )
    return data_loader


def init_model(
        device, pretrained, model_name,
        patch_size=16, crop_size=224,
        frames_per_clip=16, tubelet_size=2,
        use_sdpa=False, use_SiLU=False,
        tight_SiLU=True, uniform_power=False,
        checkpoint_key='target_encoder'
):
    encoder = vit.__dict__[model_name](img_size=crop_size, patch_size=patch_size, num_frames=frames_per_clip,
                                       tubelet_size=tubelet_size, uniform_power=uniform_power, use_sdpa=use_sdpa,
                                       use_SiLU=use_SiLU, tight_SiLU=tight_SiLU).to(device)
    return load_pretrained(encoder=encoder, pretrained=pretrained, checkpoint_key=checkpoint_key)


def init_opt(
        classifier, encoder, iterations_per_epoch,
        start_lr, ref_lr, warmup, num_epochs,
        wd=1e-6, final_wd=1e-6, final_lr=0.0, use_bfloat16=False
):
    encoder_lr = 1e-6
    encoder_params = [p for n, p in encoder.named_parameters() if p.requires_grad]
    classifier_params = [p for n, p in classifier.named_parameters() if p.requires_grad]
    param_groups = [
        {"params": encoder_params, "lr": encoder_lr, "name": "encoder"},
        {"params": classifier_params, "lr": ref_lr, "name": "classifier"}
    ]
    logger.info(f"AdamW groups: encoder_lr={encoder_lr}, classifier_lr={ref_lr}")
    optimizer = torch.optim.AdamW(param_groups, weight_decay=wd)
    scheduler = WarmupCosineSchedule(
        optimizer,
        warmup_steps=int(warmup * iterations_per_epoch),
        start_lr=start_lr,
        ref_lr=ref_lr,
        final_lr=final_lr,
        T_max=int(num_epochs * iterations_per_epoch),
    )
    wd_scheduler = CosineWDSchedule(
        optimizer,
        ref_wd=wd,
        final_wd=final_wd,
        T_max=int(num_epochs * iterations_per_epoch),
    )
    scaler = torch.amp.GradScaler() if use_bfloat16 else None
    return optimizer, scaler, scheduler, wd_scheduler