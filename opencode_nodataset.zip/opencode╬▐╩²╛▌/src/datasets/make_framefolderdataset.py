from torch.utils.data import DataLoader
from .frame_folder_dataset import FrameFolderDataset

def make_framefolderdataset(
        frames_root,
        annotation_file,
        batch_size,
        frames_per_clip,
        num_clips=1,
        random_clip_sampling=True,
        transform=None,
        num_workers=8,
        pin_memory=True,
        training=True,
        drop_last=True,
        persistent_workers=False,
        world_size=1,
        rank=0,
):
    dataset = FrameFolderDataset(
        frames_root=frames_root,
        annotation_file=annotation_file,
        frames_per_clip=frames_per_clip,
        num_clips=num_clips,
        transform=transform,
        random_clip_sampling=random_clip_sampling,
    )
    sampler = None
    if world_size > 1:
        from torch.utils.data.distributed import DistributedSampler
        sampler = DistributedSampler(dataset, num_replicas=world_size, rank=rank, shuffle=training)
    data_loader = DataLoader(
        dataset,
        batch_size=batch_size,
        sampler=sampler,
        shuffle=(sampler is None and training),
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=drop_last,
        persistent_workers=persistent_workers,
    )
    return dataset, data_loader, sampler