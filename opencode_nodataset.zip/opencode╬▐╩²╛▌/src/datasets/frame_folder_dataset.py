import os
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset

class FrameFolderDataset(Dataset):
    """
    直接从图片帧文件夹采样clip用于视频任务（如动作识别）
    要求每个视频/clip一个文件夹，帧命名有序，annotation文件指定video_id与label
    """
    def __init__(
            self,
            frames_root,         # 图片帧根目录，每个子夹一个视频clip
            annotation_file,     # CSV/TXT，每行 video_id,label
            frames_per_clip=16,  # 一个clip多少帧
            num_clips=1,         # 支持每视频多clip
            transform=None,
            random_clip_sampling=True,
    ):
        self.frames_root = frames_root
        self.frames_per_clip = frames_per_clip
        self.num_clips = num_clips
        self.transform = transform
        self.random_clip_sampling = random_clip_sampling

        self.samples = []   # 每个元素: (frame_list, label)
        with open(annotation_file, 'r') as f:
            for line in f:
                video_id, label = line.strip().split(',')[:2]
                vid_dir = os.path.join(frames_root, video_id)
                if not os.path.isdir(vid_dir):
                    continue
                frame_paths = sorted([
                    os.path.join(vid_dir, x)
                    for x in os.listdir(vid_dir)
                    if x.lower().endswith(('.jpg', '.jpeg', '.png'))
                ])
                if len(frame_paths) < frames_per_clip:
                    continue
                self.samples.append((frame_paths, int(label)))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        frame_paths, label = self.samples[idx]
        total_frames = len(frame_paths)
        clips = []
        clip_indices = []

        # 多clip采样，支持时序增强
        for _ in range(self.num_clips):
            if total_frames == self.frames_per_clip:
                start = 0
            elif total_frames < self.frames_per_clip:
                start = 0  # 也可做补帧
            else:
                if self.random_clip_sampling:
                    start = np.random.randint(0, total_frames - self.frames_per_clip + 1)
                else:
                    start = 0
            indices = np.arange(start, start + self.frames_per_clip)
            indices = np.clip(indices, 0, total_frames - 1)
            imgs = [Image.open(frame_paths[i]).convert('RGB') for i in indices]
            if self.transform:
                imgs = [self.transform(img) for img in imgs]
            clip = torch.stack(imgs, dim=0)  # [T, C, H, W]
            clips.append(clip)
            clip_indices.append(indices)
        # 输出：和VideoDataset兼容
        return clips, label, clip_indices