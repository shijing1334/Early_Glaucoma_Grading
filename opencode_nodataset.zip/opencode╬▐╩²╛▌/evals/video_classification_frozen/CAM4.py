import math
import matplotlib.pyplot as plt
# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
import os
import time
import logging
import pprint
import pickle
import pandas as pd

import numpy as np
import torch
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel

import src.models.vision_transformer as vit
from src.models.attentive_pooler import AttentiveClassifier
from src.datasets.data_manager import init_data
from src.utils.schedulers import WarmupCosineSchedule, CosineWDSchedule
from src.utils.logging import AverageMeter, CSVLogger
from evals.video_classification_frozen.utils import make_transforms, ClipAggregation, FrameAggregation

# 导入级联预测模块
from cascade_predictor import CascadePredictor

os.environ['NUMEXPR_MAX_THREADS'] = '16'
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

_GLOBAL_SEED = 3
np.random.seed(_GLOBAL_SEED)
torch.manual_seed(_GLOBAL_SEED)
torch.backends.cudnn.benchmark = False
torch.cuda.manual_seed_all(_GLOBAL_SEED)
os.environ['PYTHONHASHSEED'] = str(_GLOBAL_SEED)

pp = pprint.PrettyPrinter(indent=4)


def count_trainable_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def convert_labels_to_multi(original_labels):
    """
    Convert original 3-class labels (0,1,2) to multi-label binary (3 tasks)
    - Label 0 (非2): 1 if original label in [0,1], 0 otherwise
    - Label 1 (非0): 1 if original label in [1,2], 0 otherwise
    - Label 2 (非1): 1 if original label in [0,2], 0 otherwise

    Returns:
    - multi_labels: [batch_size, 3] tensor
    """
    batch_size = original_labels.size(0)
    multi_labels = torch.zeros(batch_size, 3, device=original_labels.device)

    # Label 0: 非2 (not class 2) -> original classes 0,1
    multi_labels[:, 0] = ((original_labels == 0) | (original_labels == 1)).float()

    # Label 1: 非0 (not class 0) -> original classes 1,2
    multi_labels[:, 1] = ((original_labels == 1) | (original_labels == 2)).float()

    # Label 2: 非1 (not class 1) -> original classes 0,2
    multi_labels[:, 2] = ((original_labels == 0) | (original_labels == 2)).float()

    return multi_labels


def extract_video_name(path):
    """Extract video name from path for matching"""
    if isinstance(path, str):
        return os.path.basename(path).split('.')[0]  # 去掉扩展名
    return str(path)
def unwrap_vit(m):
    # 递归找第一个带 blocks 的模块当作vit
    if hasattr(m, "blocks"):
        return m
    for attr in ["encoder", "backbone", "model", "module", "net"]:
        if hasattr(m, attr):
            out = unwrap_vit(getattr(m, attr))
            if out is not None:
                return out
    return None


def _hook_vit_attn_weights(vit_backbone):
    """
    给 ViT 每个 block 的 attention 打 hook，收集 attention 矩阵。
    """
    attn_maps = []
    hooks = []

    def _make_hook():
        def hook(module, inp, out):
            attn = None
            if isinstance(out, (tuple, list)) and len(out) >= 2 and torch.is_tensor(out[1]):
                attn = out[1]
            elif hasattr(module, "attn") and torch.is_tensor(getattr(module, "attn")):
                attn = getattr(module, "attn")
            elif hasattr(module, "last_attn") and torch.is_tensor(getattr(module, "last_attn")):
                attn = getattr(module, "last_attn")
            if attn is not None:
                attn_maps.append(attn.detach())
        return hook

    for blk in getattr(vit_backbone, "blocks", []):
        if hasattr(blk, "attn"):
            hooks.append(blk.attn.register_forward_hook(_make_hook()))

    return attn_maps, hooks


def attention_rollout_heatmap(attn_maps, discard_ratio=0.0):
    """
    attn_maps: list of [B, heads, N, N]
    return: w [B, N] in [0,1]
    """
    attn = [a.mean(dim=1) for a in attn_maps]  # [B,N,N]
    B, N, _ = attn[0].shape

    eye = torch.eye(N, device=attn[0].device).unsqueeze(0).expand(B, N, N)
    attn = [(a + eye) / (a + eye).sum(dim=-1, keepdim=True) for a in attn]

    joint = attn[0]
    for a in attn[1:]:
        joint = a.bmm(joint)

    w = joint.mean(dim=1)  # [B,N]

    if discard_ratio > 0:
        k = int(N * (1 - discard_ratio))
        topk, _ = torch.topk(w, k, dim=1)
        thresh = topk[:, -1].unsqueeze(1)
        w = torch.where(w >= thresh, w, torch.zeros_like(w))

    w = w - w.min(dim=1, keepdim=True).values
    w = w / (w.max(dim=1, keepdim=True).values + 1e-6)
    return w


@torch.no_grad()
@torch.no_grad()
def plot_class_frame_attention_matrix(
    encoder, data_loader, device,
    target_label=1,          # 新增：要画哪一类
    max_samples=20,
    save_path="class_frame_attention_matrix.png",
    use_bfloat16=False,
    normalize_per_video=True,
    topk=4,
):
    import numpy as np
    import matplotlib.pyplot as plt
    from collections import Counter

    encoder.eval()
    vit_backbone = unwrap_vit(encoder)
    if vit_backbone is None:
        raise RuntimeError("找不到ViT backbone（没有 .blocks ）")

    # 关闭SDPA保证hook到attention
    old_sdpa = []
    for blk in vit_backbone.blocks:
        if hasattr(blk, "attn") and hasattr(blk.attn, "use_sdpa"):
            old_sdpa.append(blk.attn.use_sdpa)
            blk.attn.use_sdpa = False
        else:
            old_sdpa.append(None)

    # -------- 1) 选出label==1的样本（保存 clips_nested + bi）--------
    selected = []
    for data in data_loader:
        clips_nested = data[0]
        labels = data[1]

        paths = None
        if len(data) > 3:
            for i in range(3, len(data)):
                if isinstance(data[i], (list, tuple)) and len(data[i]) > 0 and isinstance(data[i][0], str):
                    paths = data[i]
                    break

        y = labels.cpu().numpy()
        for bi in range(len(y)):
            if int(y[bi]) != int(target_label):
                continue
            vid_path = paths[bi] if paths is not None else f"sample_{len(selected)}"
            vid_name = extract_video_name(vid_path)
            selected.append({"video_name": vid_name, "clips_nested": clips_nested, "bi": bi})

            # 只有设置了 max_samples 才提前停止
            if max_samples is not None and len(selected) >= int(max_samples):
                break

        if max_samples is not None and len(selected) >= int(max_samples):
            break

    if len(selected) == 0:
        raise RuntimeError(f"没有找到 true_label=={target_label} 的样本")
    if max_samples is None:
        max_samples = 5

    if len(selected) > max_samples:
        rng = np.random.default_rng(_GLOBAL_SEED)  # 固定随机种子便于复现；想每次都随机可用 time.time()
        pick = rng.choice(len(selected), size=max_samples, replace=False)
        selected = [selected[i] for i in pick]
    def to_tchw(clip):
        if clip.dim() == 4 and clip.shape[0] == 3:
            return clip.permute(1, 0, 2, 3)  # [T,3,H,W]
        elif clip.dim() == 4 and clip.shape[1] == 3:
            return clip
        raise ValueError(f"未知clip形状: {tuple(clip.shape)}")

    all_scores = []
    names = []

    # -------- 2) 每个样本：对所有 temporal views 算 score（横轴=num_segments）--------
    for item in selected:
        tv = item["clips_nested"]
        bi = item["bi"]

        scores = np.zeros(len(tv), dtype=np.float32)

        for tview in range(len(tv)):
            clip_bt = tv[tview][0]   # spatial_view=0
            clip = clip_bt[bi]

            clip_tchw = to_tchw(clip)
            T = clip_tchw.shape[0]

            mid = T // 2
            t0 = min(mid, T - 2)
            two = clip_tchw[t0:t0 + 2]  # [2,3,H,W]

            x5 = two.permute(1, 0, 2, 3).unsqueeze(0).to(device, non_blocking=True)  # [1,3,2,H,W]
            clips_in = [[x5]]
            clip_indices_in = [torch.zeros(1, device=device, dtype=torch.long)]

            attn_maps, hooks = _hook_vit_attn_weights(vit_backbone)
            with torch.cuda.amp.autocast(dtype=torch.float16, enabled=use_bfloat16):
                _ = encoder(clips_in, clip_indices_in)
            for h in hooks:
                h.remove()

            if len(attn_maps) == 0:
                raise RuntimeError("没有抓到attention map（确认已关闭SDPA且hook点正确）")

            w = attention_rollout_heatmap(attn_maps)[0]  # [N]
            scores[tview] = float(w[1:].mean().item()) if w.numel() > 1 else 0.0

        if normalize_per_video:
            mn, mx = float(scores.min()), float(scores.max())
            scores = (scores - mn) / (mx - mn + 1e-6)

        all_scores.append(scores)
        names.append(item["video_name"])

    M = np.stack(all_scores, axis=0)  # [num_samples, num_segments]
    num_samples, num_segments = M.shape

    # -------- 3) 每行Top-k索引 + 全局统计 --------
    k = int(topk) if topk is not None else 0
    k = max(0, min(k, num_segments))
    topk_indices_per_row = []
    counter = Counter()

    if k > 0:
        for i in range(num_samples):
            idx = np.argsort(M[i])[-k:]          # top-k
            idx = np.sort(idx)                  # 排序便于画线
            topk_indices_per_row.append(idx)
            counter.update(idx.tolist())


    # -------- 4) 画热图（行内z-score；隐去0和最后；不画竖线）--------
    M_show = M[:, 1:-1].astype(np.float32)  # 只显示 1..num_segments-2

    # 行内标准化：更突出每个视频内部“相对重要”的segment
    row_mean = M_show.mean(axis=1, keepdims=True)
    row_std = M_show.std(axis=1, keepdims=True) + 1e-6
    Z = (M_show - row_mean) / row_std

    # 对称色阶范围
    v = np.percentile(np.abs(Z), 98)

    fig, (ax_top, ax) = plt.subplots(
        nrows=2, ncols=1,
        figsize=(max(10, (num_segments - 2) * 0.5), max(6, num_samples * 0.35) + 2),
        gridspec_kw={"height_ratios": [1, 6], "hspace": 0.05},
    )

    # 上方留空白：用于你后续覆盖图片
    ax_top.set_xlim(1, num_segments - 1)
    ax_top.set_ylim(0, 1)
    ax_top.axis("off")

    # 下方热图
    im = ax.imshow(
        Z,
        aspect="auto",
        interpolation="nearest",
        cmap="RdBu_r",
        vmin=-v, vmax=v,
        extent=(1, num_segments - 1, num_samples, 0)
    )

    cbar = fig.colorbar(im, ax=ax, fraction=0.02, pad=0.02)
    cbar.set_label("Attention")

    ax.set_yticks(np.arange(num_samples))
    ax.set_yticklabels(names, fontsize=8)

    step = max(1, (num_segments - 2) // 16)
    ax.set_xticks(np.arange(1, num_segments - 1, step))

    ax.set_xlabel(f"Temporal Segment (1–{num_segments - 2}; total={num_segments})")
    ax.set_ylabel("Early-stage Sample Index")
    ax.set_title("OCT B-scans Aligned With Temporal Segments")

    plt.tight_layout()
    plt.savefig(save_path, dpi=200)
    plt.close()
    logger.info(f"Saved heatmap to: {save_path}")
    # -------- 5) Top-k直方图（只是不显示segment0和最后一个）--------
    if k > 0:
        hist_path = os.path.splitext(save_path)[0] + f"_top{k}_hist.png"

        # 统计逻辑不变：counter 里仍包含 0..num_segments-1
        # 只是在画图时不显示 0 和 num_segments-1
        xs = np.arange(1, num_segments - 1)
        ys = np.array([counter.get(i, 0) for i in xs], dtype=np.int32)

        plt.figure(figsize=(max(10, len(xs) * 0.5), 4))
        plt.bar(xs, ys, color='steelblue')
        plt.xticks(xs)
        plt.xlabel(f"Temporal Segment (1–{num_segments-2} shown; total={num_segments})")
        plt.ylabel(f"Top-{k} Selection Frequency (over {num_samples} samples)")
        label_name = {0: "(a) Healthy", 1: "(b) Early-stage", 2: "(c) Advanced-stage"}.get(int(target_label), str(target_label))
        plt.title(f"{label_name}")
        plt.tight_layout()
        plt.savefig(hist_path, dpi=200)
        plt.close()
        logger.info(f"Saved Top-{k} histogram to: {hist_path}")

    # 恢复SDPA
    for blk, v in zip(vit_backbone.blocks, old_sdpa):
        if v is not None:
            blk.attn.use_sdpa = v

def main(args_eval, resume_preempt=False, top_k_thresholds=20):
    # -------- Extract parameters --------
    args_pretrain = args_eval.get('pretrain', {})
    checkpoint_key = args_pretrain.get('checkpoint_key', 'target_encoder')
    model_name = args_pretrain.get('model_name')
    patch_size = args_pretrain.get('patch_size')
    pretrain_folder = args_pretrain.get('folder')
    ckp_fname = args_pretrain.get('checkpoint')
    tag = args_pretrain.get('write_tag')
    use_sdpa = args_pretrain.get('use_sdpa', True)
    use_SiLU = args_pretrain.get('use_silu', False)
    tight_SiLU = args_pretrain.get('tight_silu', True)
    uniform_power = args_pretrain.get('uniform_power', False)
    # 只有预训练模型路径使用 pretrain_folder
    pretrained_path = os.path.join(pretrain_folder, ckp_fname) if pretrain_folder and ckp_fname else None
    tubelet_size = args_pretrain.get('tubelet_size', 2)
    pretrain_frames_per_clip = args_pretrain.get('frames_per_clip', 1)

    # 从配置读取权重路径（独立的相对/绝对路径）
    encoder_weights_path = args_pretrain.get('encoder_weights', 'encoder_epoch_23.pth')
    classifier_weights_path = args_pretrain.get('classifier_weights', 'classifier_epoch_23.pth')

    args_data = args_eval.get('data', {})
    train_data_path = [args_data.get('dataset_train')]
    val_data_path = [args_data.get('dataset_val')]
    dataset_type = args_data.get('dataset_type', 'VideoDataset')
    num_classes = args_data.get('num_classes')
    eval_num_segments = args_data.get('num_segments', 16)
    eval_frames_per_clip = args_data.get('frames_per_clip', 16)
    eval_frame_step = args_pretrain.get('frame_step', 1)
    eval_duration = args_pretrain.get('clip_duration')
    eval_num_views_per_segment = args_data.get('num_views_per_segment', 1)

    args_opt = args_eval.get('optimization', {})
    resolution = args_opt.get('resolution', 224)
    batch_size = args_opt.get('batch_size')
    attend_across_segments = args_opt.get('attend_across_segments', False)
    num_epochs = args_opt.get('num_epochs', 1)  # 运行的epoch数
    wd = args_opt.get('weight_decay')
    start_lr = args_opt.get('start_lr')
    lr = args_opt.get('lr')
    final_lr = args_opt.get('final_lr')
    warmup = args_opt.get('warmup')
    use_bfloat16 = args_opt.get('use_bfloat16', False)

    # Cascade prediction配置（独立的相对/绝对路径）
    cascade_config = args_eval.get('cascade', {})
    three_class_model_path = cascade_config.get('three_class_model_path', 'best_model.pth')
    three_class_csv_path = cascade_config.get('three_class_csv_path', 'val_image.csv')
    selected_model = cascade_config.get('selected_model', 'best_efficientnet_b3_seed_125')

    # 读取阈值列表（直接使用配置文件中的固定值）
    cascade_thresholds = cascade_config.get('cascade_thresholds', [0.8, 0.8, 0.8])

    # 兼容旧阈值参数
    if 'threshold_non2' in cascade_config or 'threshold_non0' in cascade_config or 'threshold_non1' in cascade_config:
        logger.warning("发现旧的阈值参数。请使用 'cascade_thresholds' 列表格式。")
        cascade_thresholds = [
            cascade_config.get('threshold_non2', 0.0),
            cascade_config.get('threshold_non0', 0.0),
            cascade_config.get('threshold_non1', 0.0)
        ]

    # 创建权重保存目录（仅用于记录，不会保存新权重）
    if pretrain_folder:
        weights_dir = os.path.join(pretrain_folder, 'weights')
        logger.info(f"预训练权重目录: {weights_dir}")

    # 解析并验证所有路径（转换为绝对路径便于日志显示）
    encoder_weights_abs = os.path.abspath(encoder_weights_path)
    classifier_weights_abs = os.path.abspath(classifier_weights_path)
    three_class_model_abs = os.path.abspath(three_class_model_path)
    three_class_csv_abs = os.path.abspath(three_class_csv_path)

    # 打印路径信息，方便调试
    logger.info(f"编码器权重路径: {encoder_weights_abs} (原始配置: {encoder_weights_path})")
    logger.info(f"分类器权重路径: {classifier_weights_abs} (原始配置: {classifier_weights_path})")
    logger.info(f"三分类模型路径: {three_class_model_abs} (原始配置: {three_class_model_path})")
    logger.info(f"三分类CSV路径: {three_class_csv_abs} (原始配置: {three_class_csv_path})")

    device = torch.device('cuda:0') if torch.cuda.is_available() else torch.device('cpu')
    if device.type == 'cuda':
        torch.cuda.set_device(device)

    # 创建用于日志的文件夹
    if pretrain_folder:
        os.makedirs(pretrain_folder, exist_ok=True)
        log_file = os.path.join(pretrain_folder, f'{tag}_inference.csv')
    else:
        # 如果没有pretrain_folder，日志文件保存在当前目录
        log_file = f'{tag}_inference.csv'

    # 初始化 cascade predictor（使用配置文件中的固定阈值）
    cascade_predictor = CascadePredictor(
        model_path=three_class_model_path,  # 使用原始路径（支持相对/绝对）
        csv_path=three_class_csv_path,  # 使用原始路径（支持相对/绝对）
        selected_model=selected_model,
        device=device,
        cascade_thresholds=cascade_thresholds
    )
    logger.info(f"Cascade predictor initialized with fixed thresholds: {cascade_thresholds}")
    fixed_thresholds = (
        cascade_predictor.threshold_non2,
        cascade_predictor.threshold_non0,
        cascade_predictor.threshold_non1
    )
    logger.info(f"使用的固定阈值: non2={fixed_thresholds[0]}, non0={fixed_thresholds[1]}, non1={fixed_thresholds[2]}")

    # 初始化并冻结编码器
    if pretrained_path and os.path.exists(pretrained_path):
        encoder = init_model(
            crop_size=resolution,
            device=device,
            pretrained=pretrained_path,
            model_name=model_name,
            patch_size=patch_size,
            tubelet_size=tubelet_size,
            frames_per_clip=pretrain_frames_per_clip,
            uniform_power=uniform_power,
            checkpoint_key=checkpoint_key,
            use_SiLU=use_SiLU,
            tight_SiLU=tight_SiLU
        )
    else:
        logger.warning(f"预训练模型路径不存在: {pretrained_path}，使用随机初始化")
        encoder = init_model(
            crop_size=resolution,
            device=device,
            pretrained=None,
            model_name=model_name,
            patch_size=patch_size,
            tubelet_size=tubelet_size,
            frames_per_clip=pretrain_frames_per_clip,
            uniform_power=uniform_power,
            checkpoint_key=checkpoint_key,
            use_SiLU=use_SiLU,
            tight_SiLU=tight_SiLU
        )

    if pretrain_frames_per_clip == 1:
        encoder = FrameAggregation(encoder).to(device)
    else:
        encoder = ClipAggregation(
            encoder,
            tubelet_size=tubelet_size,
            attend_across_segments=attend_across_segments
        ).to(device)

    # 冻结所有参数
    for p in encoder.parameters():
        p.requires_grad = False

    # 初始化多标签分类器
    classifier = AttentiveClassifier(
        embed_dim=encoder.embed_dim,
        num_heads=encoder.num_heads,
        depth=1,
        num_classes=3,  # 三个任务的多标签分类
    ).to(device)

    # 记录可训练参数的总数（应为0）
    enc_params = count_trainable_parameters(encoder)
    cls_params = count_trainable_parameters(classifier)
    logger.info(f"Trainable encoder params: {enc_params:,}")
    logger.info(f"Trainable classifier params: {cls_params:,}")
    logger.info(f"Total trainable params: {enc_params + cls_params:,}")

    # 数据加载器 - 只需要验证集
    val_loader = make_dataloader(
        dataset_type=dataset_type,
        root_path=val_data_path,
        resolution=resolution,
        frames_per_clip=eval_frames_per_clip,
        frame_step=eval_frame_step,
        num_segments=eval_num_segments,
        eval_duration=eval_duration,
        num_views_per_segment=eval_num_views_per_segment,
        allow_segment_overlap=True,
        batch_size=batch_size,
        training=False
    )

    logger.info(f'Dataloader iterations per epoch: {len(val_loader)}')

    # 创建空的优化器和调度器（不会使用）
    optimizer, scaler, scheduler, wd_scheduler = None, None, None, None

    # 加载指定的权重文件
    logger.info(f"加载权重: {encoder_weights_path} 和 {classifier_weights_path}")
    # 增加文件存在性检查
    if not os.path.exists(encoder_weights_path):
        logger.error(f"编码器权重文件不存在: {encoder_weights_path} (绝对路径: {encoder_weights_abs})")
        raise FileNotFoundError(f"Encoder weights file not found: {encoder_weights_path}")
    if not os.path.exists(classifier_weights_path):
        logger.error(f"分类器权重文件不存在: {classifier_weights_path} (绝对路径: {classifier_weights_abs})")
        raise FileNotFoundError(f"Classifier weights file not found: {classifier_weights_path}")

    encoder.load_state_dict(torch.load(encoder_weights_path, map_location=device))
    classifier.load_state_dict(torch.load(classifier_weights_path, map_location=device))
    logger.info(f"成功加载权重文件")

    # 推理循环
    for epoch in range(num_epochs):
        epoch_start = time.time()
        logger.info(f'Starting inference epoch {epoch + 1}')

        # 运行验证（使用固定阈值）
        val_acc_non2, val_acc_non0, val_acc_non1, val_predictions = run_one_epoch(
            device=device,
            training=False,
            num_temporal_views=eval_num_segments,
            attend_across_segments=attend_across_segments,
            num_spatial_views=eval_num_views_per_segment,
            encoder=encoder,
            classifier=classifier,
            scaler=scaler,
            optimizer=optimizer,
            scheduler=scheduler,
            wd_scheduler=wd_scheduler,
            data_loader=val_loader,
            use_bfloat16=use_bfloat16,
            save_predictions=True
        )
        plot_class_frame_attention_matrix(
            encoder=encoder,
            data_loader=val_loader,
            device=device,
            target_label=1,
            max_samples=None,
            save_path=os.path.join(pretrain_folder if pretrain_folder else ".",
                                   f"{tag}_class0_frame_attn_matrix_epoch{epoch + 1}.png"),
            use_bfloat16=use_bfloat16,
            normalize_per_video=True,
            topk=1,
        )

        if val_predictions is not None and len(val_predictions) > 0:
            pred_save_path = os.path.join(pretrain_folder if pretrain_folder else '.',
                                          f"{tag}_inference_epoch{epoch + 1}_val_predictions.csv")
            pd.DataFrame(val_predictions).to_csv(pred_save_path, index=False)
            logger.info(f"Saved inference predictions for epoch {epoch + 1} to {pred_save_path}")

        logger.info(
            f'[Inference][Epoch {epoch + 1}] Acc_non2: {val_acc_non2:.3f}% | Acc_non0: {val_acc_non0:.3f}% | Acc_non1: {val_acc_non1:.3f}%')

        # 直接使用配置文件中的固定阈值运行级联预测（仅一次）
        cascade_acc, cascade_kappa = cascade_predictor.predict(val_predictions)
        logger.info(f'\n[Inference][Epoch {epoch + 1}] 固定阈值性能: '
                    f'Thresholds(non2={fixed_thresholds[0]}, non0={fixed_thresholds[1]}, non1={fixed_thresholds[2]}) | '
                    f'Acc={cascade_acc:.3f}% | Kappa={cascade_kappa:.4f}')

        # 记录主日志
        csv_logger = CSVLogger(log_file,
                               ('%d', 'epoch'),
                               ('%.5f', 'acc_non2_val'),
                               ('%.5f', 'acc_non0_val'),
                               ('%.5f', 'acc_non1_val'),
                               ('%.5f', 'cascade_acc'),
                               ('%.5f', 'cascade_kappa'))
        csv_logger.log(epoch + 1, val_acc_non2, val_acc_non0, val_acc_non1, cascade_acc, cascade_kappa)

        epoch_end = time.time()
        logger.info(f'Epoch {epoch + 1} duration: {epoch_end - epoch_start:.2f} seconds\n')


def run_one_epoch(
        device,
        training,
        encoder,
        classifier,
        scaler,
        optimizer,
        scheduler,
        wd_scheduler,
        data_loader,
        use_bfloat16,
        num_spatial_views,
        num_temporal_views,
        attend_across_segments,
        save_predictions=False
):
    import torch
    from collections import Counter
    import numpy as np
    from torch.nn import functional as F

    # 确保模型处于评估模式
    encoder.eval()
    classifier.eval()

    criterion = torch.nn.BCEWithLogitsLoss()
    acc_non2_meter = AverageMeter()
    acc_non0_meter = AverageMeter()
    acc_non1_meter = AverageMeter()

    # 用于预测保存
    predictions_data = []
    seen_labels = set()
    all_label_list = []

    for itr, data in enumerate(data_loader):
        with torch.no_grad():
            with torch.cuda.amp.autocast(dtype=torch.float16, enabled=use_bfloat16):
                clips = [
                    [dij.to(device, non_blocking=True) for dij in di]
                    for di in data[0]
                ]
                clip_indices = [d.to(device, non_blocking=True) for d in data[2]]
                original_labels = data[1].to(device)
                batch_size = original_labels.size(0)

                # 路径获取
                video_paths = []
                if len(data) > 3:
                    for i in range(3, len(data)):
                        if isinstance(data[i], (list, tuple)) and len(data[i]) > 0:
                            if isinstance(data[i][0], str):
                                video_paths = data[i]
                                break
                if not video_paths:
                    video_paths = [f"sample_{itr * batch_size + i}" for i in range(batch_size)]

                # 多标签处理
                multi_labels = convert_labels_to_multi(original_labels)

                unique = original_labels.unique().cpu().numpy().tolist()
                seen_labels.update(unique)
                all_label_list.extend(original_labels.cpu().numpy().tolist())

                outputs = encoder(clips, clip_indices)

                if attend_across_segments:
                    outputs_logits = [classifier(o) for o in outputs]
                else:
                    outputs_logits = [[classifier(o) for o in seq] for seq in outputs]

            # 损失计算（仅用于记录）
            if attend_across_segments:
                loss = sum(criterion(o, multi_labels) for o in outputs_logits) / len(outputs_logits)
            else:
                loss = sum(sum(criterion(o, multi_labels) for o in seq) for seq in outputs_logits) / (
                        len(outputs_logits) * len(outputs_logits[0]))

            with torch.no_grad():
                # 融合 batch 预测（计算平均logits）
                if attend_across_segments:
                    avg_logits = sum(o for o in outputs_logits) / len(outputs_logits)
                else:
                    avg_logits = sum(sum(o for o in seq) for seq in outputs_logits) / (
                            len(outputs_logits) * len(outputs_logits[0]))

                # 通过sigmoid将logits转换为0-1之间的概率
                pred_probs = torch.sigmoid(avg_logits)  # shape: [batch, 3]，值严格在(0,1)之间

                # 基于概率的预测（阈值0.5）
                predictions = pred_probs > 0.5
                true_multi = multi_labels.bool()

                # 保存预测结果
                if save_predictions:
                    for i in range(batch_size):
                        video_name = extract_video_name(video_paths[i] if i < len(video_paths) else f"sample_{i}")

                        # 调试：检查non0概率范围，确保在0-1之间
                        non0_score = pred_probs[i, 1].cpu().item()
                        if not (0 <= non0_score <= 1):
                            logger.warning(
                                f"non0概率异常: {non0_score:.4f} (视频: {video_name}, logit值: {avg_logits[i, 1].cpu().item():.4f})"
                            )

                        predictions_data.append({
                            'video_name': video_name,
                            'video_path': video_paths[i] if i < len(video_paths) else f"sample_{i}",
                            'true_label': original_labels[i].cpu().item(),
                            # 仅保留sigmoid处理后的概率（确保在0-1之间）
                            'pred_non2_score': pred_probs[i, 0].cpu().item(),
                            'pred_non0_score': non0_score,  # 使用检查后的non0概率
                            'pred_non1_score': pred_probs[i, 2].cpu().item(),
                            'true_non2': true_multi[i, 0].cpu().item(),
                            'true_non0': true_multi[i, 1].cpu().item(),
                            'true_non1': true_multi[i, 2].cpu().item()
                        })

                # 三任务独立准确率计算
                acc_non2 = 100. * (predictions[:, 0] == true_multi[:, 0]).float().sum() / batch_size
                acc_non2_meter.update(acc_non2)

                acc_non0 = 100. * (predictions[:, 1] == true_multi[:, 1]).float().sum() / batch_size
                acc_non0_meter.update(acc_non0)

                acc_non1 = 100. * (predictions[:, 2] == true_multi[:, 2]).float().sum() / batch_size
                acc_non1_meter.update(acc_non1)

        if itr % 20 == 0:
            logger.info(
                f'[{itr:5d}] Acc_non2: {acc_non2_meter.avg:.3f}% | Acc_non0: {acc_non0_meter.avg:.3f}% | Acc_non1: {acc_non1_meter.avg:.3f}% | '
                f'Loss: {loss:.3f} | Mem: {torch.cuda.max_memory_allocated() / 1024. ** 2:.2f} MB')

    logger.info(f"[Epoch End] Seen labels: {sorted(seen_labels)}; Counts: {dict(Counter(all_label_list))}")

    if save_predictions:
        return acc_non2_meter.avg, acc_non0_meter.avg, acc_non1_meter.avg, predictions_data
    else:
        return acc_non2_meter.avg, acc_non0_meter.avg, acc_non1_meter.avg


# 其他函数保持不变...
def load_checkpoint(device, r_path, classifier, opt, scaler):
    try:
        ckpt = torch.load(r_path, map_location='cpu')
        epoch = ckpt.get('epoch', 0)
        msg = classifier.load_state_dict(ckpt['classifier'])
        logger.info(f'Loaded classifier from epoch {epoch}: {msg}')
        opt.load_state_dict(ckpt['opt'])
        if scaler:
            scaler.load_state_dict(ckpt['scaler'])
        logger.info(f'Loaded optimizer/scaler from {r_path}')
    except Exception as e:
        logger.info(f'Error loading checkpoint: {e}')
        epoch = 0
    return classifier, opt, scaler, epoch


def load_pretrained(encoder, pretrained, checkpoint_key='target_encoder'):
    if not pretrained:
        logger.info("未指定预训练模型路径，使用随机初始化")
        return encoder

    logger.info(f'Loading pretrained model from {pretrained}')
    ckpt = torch.load(pretrained, map_location='cpu')
    pdict = ckpt.get(checkpoint_key, ckpt.get('encoder', {}))
    pdict = {k.replace('module.', '').replace('backbone.', ''): v for k, v in pdict.items()}
    model_dict = encoder.state_dict()
    for k in list(model_dict.keys()):
        if k not in pdict or pdict[k].shape != model_dict[k].shape:
            logger.info(f'Key "{k}" missing or shape mismatch; using model default.')
            pdict[k] = model_dict[k]
    msg = encoder.load_state_dict(pdict, strict=False)
    logger.info(f'Loaded pretrained encoder with msg: {msg}')
    return encoder


def make_dataloader(
        root_path, batch_size,
        dataset_type='VideoDataset', resolution=224,
        frames_per_clip=16, frame_step=1, num_segments=16,
        eval_duration=None, num_views_per_segment=1,
        allow_segment_overlap=True, training=False, num_workers=8, subset_file=None
):
    transform = make_transforms(
        training=training,
        num_views_per_clip=num_views_per_segment,
        random_horizontal_flip=False,
        random_resize_aspect_ratio=(1, 1),
        random_resize_scale=(1, 1.0),
        reprob=0.25,
        auto_augment=False,
        motion_shift=False,
        crop_size=resolution,
    )
    data_loader, _ = init_data(
        data=dataset_type,
        root_path=root_path,
        transform=transform,
        batch_size=batch_size,
        clip_len=frames_per_clip,
        frame_sample_rate=frame_step,
        duration=eval_duration,
        num_clips=num_segments,
        allow_clip_overlap=allow_segment_overlap,
        num_workers=num_workers,
        copy_data=False,
        drop_last=False,
        subset_file=subset_file
    )
    return data_loader


def init_model(
        device, pretrained, model_name,
        patch_size=16, crop_size=224,
        frames_per_clip=16, tubelet_size=2,
        use_sdpa=False, use_SiLU=False,
        tight_SiLU=True, uniform_power=False,
        checkpoint_key='target_encoder'
):
    encoder = vit.__dict__[model_name](img_size=crop_size, patch_size=patch_size, num_frames=frames_per_clip,
                                       tubelet_size=tubelet_size, uniform_power=uniform_power, use_sdpa=use_sdpa,
                                       use_SiLU=use_SiLU, tight_SiLU=tight_SiLU).to(device)
    return load_pretrained(encoder=encoder, pretrained=pretrained, checkpoint_key=checkpoint_key)


def init_opt(
        classifier, encoder, iterations_per_epoch,
        start_lr, ref_lr, warmup, num_epochs,
        wd=1e-6, final_wd=1e-6, final_lr=0.0, use_bfloat16=False
):
    encoder_lr = 1e-6
    encoder_params = [p for n, p in encoder.named_parameters() if p.requires_grad]
    classifier_params = [p for n, p in classifier.named_parameters() if p.requires_grad]
    param_groups = [
        {"params": encoder_params, "lr": encoder_lr, "name": "encoder"},
        {"params": classifier_params, "lr": ref_lr, "name": "classifier"}
    ]
    logger.info(f"AdamW groups: encoder_lr={encoder_lr}, classifier_lr={ref_lr}")
    optimizer = torch.optim.AdamW(param_groups, weight_decay=wd)
    scheduler = WarmupCosineSchedule(
        optimizer,
        warmup_steps=int(warmup * iterations_per_epoch),
        start_lr=start_lr,
        ref_lr=ref_lr,
        final_lr=final_lr,
        T_max=int(num_epochs * iterations_per_epoch),
    )
    wd_scheduler = CosineWDSchedule(
        optimizer,
        ref_wd=wd,
        final_wd=final_wd,
        T_max=int(num_epochs * iterations_per_epoch),
    )
    scaler = torch.amp.GradScaler() if use_bfloat16 else None
    return optimizer, scaler, scheduler, wd_scheduler